# Installation Guide

## Quick Install (3 Steps)

### Step 1: Prerequisites

Ensure you have Python 3.7 or higher installed:

```bash
python --version
# or
python3 --version
```

If you don't have Python installed, download it from [python.org](https://www.python.org/downloads/)

### Step 2: Install Dependencies

```bash
# Navigate to project directory
cd parquet-retrieval

# Install required packages
pip install -r requirements.txt
```

**Note:** On some systems, you may need to use `pip3` instead of `pip`:

```bash
pip3 install -r requirements.txt
```

### Step 3: Verify Installation

```bash
# Test the pipeline with help command
python generate_rmc_reports.py --help
```

You should see usage instructions if everything is installed correctly.

## Alternative: Using Virtual Environment (Recommended)

Using a virtual environment keeps dependencies isolated:

### On macOS/Linux:

```bash
# Navigate to project directory
cd parquet-retrieval

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the pipeline
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

### On Windows:

```bash
# Navigate to project directory
cd parquet-retrieval

# Create virtual environment
python -m venv venv

# Activate virtual environment
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the pipeline
python generate_rmc_reports.py input_files\tuscan\loan_tape.csv input_files\tuscan\security_tape.csv
```

## Troubleshooting

### Issue: "pip: command not found"

**Solution:** Use `pip3` instead:
```bash
pip3 install -r requirements.txt
```

### Issue: "Permission denied" when installing packages

**Solution:** Use the `--user` flag:
```bash
pip install --user -r requirements.txt
```

### Issue: Package installation fails

**Solution:** Upgrade pip first:
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Issue: Python version too old

**Solution:** You need Python 3.7+. Check your version:
```bash
python --version
```

If it's older than 3.7, install a newer version from [python.org](https://www.python.org/downloads/)

## Dependencies Explained

This project requires the following Python packages:

- **pandas** (2.1.3) - Data manipulation and CSV/Excel handling
- **pyarrow** (14.0.1) - Parquet file format support
- **openpyxl** (3.1.2) - Excel file writing
- **duckdb** (0.9.2) - Fast SQL query engine

## Testing Your Setup

After installation, test with the included sample data:

```bash
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

You should see output similar to:

```
================================================================================
RMC TUSCAN REPORT PIPELINE
================================================================================
Start time: 2025-10-31 11:00:00

...

PIPELINE COMPLETED SUCCESSFULLY!
Duration: 2.88 seconds
✓ All reports generated successfully!
```

Check the `output_files/` directory for generated reports organized by month-year.

### Verify Environment

If you encounter any issues, run the diagnostic script:

```bash
python diagnose_environment.py
```

This will check for:
- All required files
- Optional files (sic_code.xlsx, risk_info.xlsx)
- Python packages
- Schema consistency

## Next Steps

- Read [README.md](README.md) for project overview
- See [QUICK_REFERENCE.md](QUICK_REFERENCE.md) for command examples
- Check [PIPELINE_USER_GUIDE.md](PIPELINE_USER_GUIDE.md) for detailed documentation

## Getting Help

If you encounter issues not covered here:
1. Check that all input files exist and are properly formatted
2. Verify SQL query files exist in `tuscan_queries/` directory
3. Ensure you have write permissions to `output_files/` directory

