#!/bin/bash

###############################################################################
# RMC Reports Pipeline - Example Runner
# 
# Quick script to run the pipeline with the included sample data
###############################################################################

# Determine Python command
if command -v python3 &> /dev/null; then
    PYTHON_CMD=python3
else
    PYTHON_CMD=python
fi

echo "=========================================="
echo "Running RMC Reports Pipeline"
echo "=========================================="
echo ""
echo "Using sample data from input_files/tuscan/"
echo ""

# Run the pipeline
$PYTHON_CMD generate_rmc_reports.py \
    input_files/tuscan/loan_tape.csv \
    input_files/tuscan/security_tape.csv

echo ""
echo "=========================================="
echo "Check the output_files/ directory for generated reports!"
echo "=========================================="

