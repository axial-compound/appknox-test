#!/usr/bin/env python3
"""
RMC Tuscan Report Pipeline
==========================
Automated pipeline for generating Tuscan RMC reports from input CSV files.

Usage:
    python generate_rmc_reports.py <loan_tape.csv> <security_tape.csv>
    python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
    
Pipeline Steps:
    1. Convert input CSV files to Parquet format
    2. Execute rmc_tuscan.sql to generate intermediate report
    3. Convert intermediate report to rmc_tuscan.parquet
    4. Execute rmc_tuscan_masterfile.sql to generate masterfile report
    5. Execute rmc_tuscan_IRFS9.sql to generate IFRS9 report
"""

import sys
import os
import duckdb
import pandas as pd
from datetime import datetime
from pathlib import Path


class RMCReportPipeline:
    """Automated pipeline for RMC Tuscan report generation"""
    
    def __init__(self, loan_tape_csv, security_tape_csv, risk_info_xlsx=None, sic_code_xlsx=None):
        self.loan_tape_csv = loan_tape_csv
        self.security_tape_csv = security_tape_csv
        
        # Optional Excel files (auto-detect if not provided)
        self.risk_info_xlsx = risk_info_xlsx or Path("input_files/tuscan/risk_info.xlsx")
        self.sic_code_xlsx = sic_code_xlsx or Path("input_files/tuscan/sic_code.xlsx")
        
        # Define paths
        self.parquet_dir = Path("parquet_files")
        self.output_base_dir = Path("output_files")
        self.queries_dir = Path("tuscan_queries")
        
        # Create base directories if they don't exist
        self.parquet_dir.mkdir(exist_ok=True)
        self.output_base_dir.mkdir(exist_ok=True)
        
        # Report date will be determined after reading the data
        self.report_date_folder = None
        self.output_dir = None
        
        # Define file paths
        self.loan_tape_parquet = self.parquet_dir / "loan_tape.parquet"
        self.security_tape_parquet = self.parquet_dir / "security_tape.parquet"
        self.risk_info_parquet = self.parquet_dir / "risk_info.parquet"
        self.sic_code_parquet = self.parquet_dir / "sic_code.parquet"
        self.rmc_tuscan_parquet = self.parquet_dir / "rmc_tuscan.parquet"
        
        # Output file paths will be set after determining report date
        self.rmc_tuscan_xlsx = None
        self.rmc_masterfile_xlsx = None
        self.rmc_ifrs9_xlsx = None
        
        self.rmc_tuscan_sql = self.queries_dir / "rmc_tuscan.sql"
        self.rmc_masterfile_sql = self.queries_dir / "rmc_tuscan_masterfile.sql"
        self.rmc_ifrs9_sql = self.queries_dir / "rmc_tuscan_IRFS9.sql"
        
    def print_step(self, step_num, total_steps, message):
        """Print a formatted step message"""
        print(f"\n{'='*80}")
        print(f"STEP {step_num}/{total_steps}: {message}")
        print(f"{'='*80}")
    
    def print_success(self, message, details=None):
        """Print a success message"""
        print(f"✓ {message}")
        if details:
            for key, value in details.items():
                print(f"  - {key}: {value}")
    
    def print_error(self, message):
        """Print an error message"""
        print(f"✗ ERROR: {message}", file=sys.stderr)
    
    def validate_inputs(self):
        """Validate that input files exist"""
        print("\nValidating input files...")
        
        if not os.path.exists(self.loan_tape_csv):
            raise FileNotFoundError(f"Loan tape CSV not found: {self.loan_tape_csv}")
        
        if not os.path.exists(self.security_tape_csv):
            raise FileNotFoundError(f"Security tape CSV not found: {self.security_tape_csv}")
        
        # Optional files - warn if missing but don't fail
        if not os.path.exists(self.risk_info_xlsx):
            print(f"  Warning: Risk info Excel not found: {self.risk_info_xlsx} (will skip)")
            self.risk_info_xlsx = None
        
        if not os.path.exists(self.sic_code_xlsx):
            print(f"  Warning: SIC code Excel not found: {self.sic_code_xlsx} (will skip)")
            self.sic_code_xlsx = None
        
        if not self.rmc_tuscan_sql.exists():
            raise FileNotFoundError(f"SQL file not found: {self.rmc_tuscan_sql}")
        
        if not self.rmc_masterfile_sql.exists():
            raise FileNotFoundError(f"SQL file not found: {self.rmc_masterfile_sql}")
        
        if not self.rmc_ifrs9_sql.exists():
            raise FileNotFoundError(f"SQL file not found: {self.rmc_ifrs9_sql}")
        
        self.print_success("All input files validated")
    
    def setup_output_folder(self):
        """Setup output folder based on current date when script runs"""
        # Use current date (when script is run)
        current_date = datetime.now()
        
        # Format as mm-yyyy
        self.report_date_folder = current_date.strftime('%m-%Y')
        self.output_dir = self.output_base_dir / self.report_date_folder
        
        # Create the date-specific output directory
        self.output_dir.mkdir(exist_ok=True)
        
        # Set output file paths
        self.rmc_tuscan_xlsx = self.output_dir / "rmc_tuscan_report.xlsx"
        self.rmc_masterfile_xlsx = self.output_dir / "rmc_masterfile_report.xlsx"
        self.rmc_ifrs9_xlsx = self.output_dir / "rmc_ifrs9_report.xlsx"
        
        print(f"  Current date: {current_date.strftime('%Y-%m-%d')}")
        print(f"  Output folder: {self.output_dir}")
    
    def csv_to_parquet(self, csv_file, parquet_file, description):
        """Convert CSV file to Parquet format"""
        print(f"\nConverting {description}...")
        print(f"  Input:  {csv_file}")
        print(f"  Output: {parquet_file}")
        
        # Read CSV
        df = pd.read_csv(csv_file)
        
        # Convert to Parquet
        df.to_parquet(parquet_file, engine='pyarrow', compression='snappy', index=False)
        
        # Get file sizes
        csv_size = os.path.getsize(csv_file)
        parquet_size = os.path.getsize(parquet_file)
        compression_ratio = (1 - parquet_size / csv_size) * 100
        
        self.print_success(
            f"Converted {description}",
            {
                "Rows": len(df),
                "Columns": len(df.columns),
                "CSV size": f"{csv_size:,} bytes",
                "Parquet size": f"{parquet_size:,} bytes",
                "Compression": f"{compression_ratio:.1f}%"
            }
        )
        
        return df
    
    def excel_to_parquet_input(self, excel_file, parquet_file, description):
        """Convert Excel file to Parquet format"""
        print(f"\nConverting {description}...")
        print(f"  Input:  {excel_file}")
        print(f"  Output: {parquet_file}")
        
        # Read Excel
        df = pd.read_excel(excel_file)
        
        # Convert to Parquet
        df.to_parquet(parquet_file, engine='pyarrow', compression='snappy', index=False)
        
        # Get file sizes
        excel_size = os.path.getsize(excel_file)
        parquet_size = os.path.getsize(parquet_file)
        compression_ratio = (1 - parquet_size / excel_size) * 100
        
        self.print_success(
            f"Converted {description}",
            {
                "Rows": len(df),
                "Columns": len(df.columns),
                "Excel size": f"{excel_size:,} bytes",
                "Parquet size": f"{parquet_size:,} bytes",
                "Compression": f"{compression_ratio:.1f}%"
            }
        )
        
        return df
    
    def execute_sql_query(self, sql_file, description):
        """Execute a SQL query and return the result"""
        print(f"\nExecuting {description}...")
        print(f"  SQL file: {sql_file}")
        
        # Read SQL query
        with open(sql_file, 'r') as f:
            query = f.read()
        
        # Execute query
        con = duckdb.connect()
        try:
            df = con.execute(query).fetchdf()
            
            self.print_success(
                f"Query executed successfully",
                {
                    "Rows": len(df),
                    "Columns": len(df.columns)
                }
            )
            
            return df
        except Exception as e:
            self.print_error(f"Query execution failed: {e}")
            raise
        finally:
            con.close()
    
    def export_to_excel(self, df, excel_file, description):
        """Export DataFrame to Excel with formatting"""
        print(f"\nExporting to Excel: {description}...")
        print(f"  Output: {excel_file}")
        
        # Export to Excel
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Report')
            
            # Auto-adjust column widths
            worksheet = writer.sheets['Report']
            for idx, col in enumerate(df.columns, 1):
                try:
                    # Calculate max length for column
                    max_length = max(
                        df[col].astype(str).apply(len).max(),
                        len(str(col))
                    ) + 2
                    
                    # Get Excel column letter (handles columns beyond Z)
                    if idx <= 26:
                        col_letter = chr(64 + idx)
                    else:
                        # For columns beyond Z (AA, AB, etc.)
                        first = chr(64 + ((idx - 1) // 26))
                        second = chr(65 + ((idx - 1) % 26))
                        col_letter = first + second
                    
                    worksheet.column_dimensions[col_letter].width = min(max_length, 50)
                except Exception as e:
                    # Skip column width adjustment if there's an issue
                    print(f"  Warning: Could not adjust width for column {idx}: {col}")
        
        file_size = os.path.getsize(excel_file)
        
        self.print_success(
            f"Excel file created",
            {
                "File": excel_file,
                "Size": f"{file_size:,} bytes ({file_size/1024:.2f} KB)"
            }
        )
    
    def excel_to_parquet(self, excel_file, parquet_file, description):
        """Convert Excel file to Parquet format"""
        print(f"\nConverting {description} to Parquet...")
        print(f"  Input:  {excel_file}")
        print(f"  Output: {parquet_file}")
        
        # Read Excel
        df = pd.read_excel(excel_file, sheet_name='Report')
        
        # Convert to Parquet
        df.to_parquet(parquet_file, engine='pyarrow', compression='snappy', index=False)
        
        parquet_size = os.path.getsize(parquet_file)
        
        self.print_success(
            f"Parquet file created",
            {
                "Rows": len(df),
                "Columns": len(df.columns),
                "Size": f"{parquet_size:,} bytes"
            }
        )
    
    def run(self):
        """Execute the complete pipeline"""
        start_time = datetime.now()
        total_steps = 5
        
        print("\n" + "="*80)
        print("RMC TUSCAN REPORT PIPELINE")
        print("="*80)
        print(f"Start time: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            # Validate inputs
            self.validate_inputs()
            
            # Setup output folder structure based on current date
            print("\nSetting up output folder...")
            self.setup_output_folder()
            
            # Step 1: Convert input CSV and Excel files to Parquet
            self.print_step(1, total_steps, "Convert input files to Parquet")
            self.csv_to_parquet(self.loan_tape_csv, self.loan_tape_parquet, "Loan Tape CSV")
            self.csv_to_parquet(self.security_tape_csv, self.security_tape_parquet, "Security Tape CSV")
            
            # Convert optional Excel files if they exist
            if self.risk_info_xlsx:
                self.excel_to_parquet_input(self.risk_info_xlsx, self.risk_info_parquet, "Risk Info Excel")
            
            if self.sic_code_xlsx:
                self.excel_to_parquet_input(self.sic_code_xlsx, self.sic_code_parquet, "SIC Code Excel")
            
            # Step 2: Execute rmc_tuscan.sql to generate intermediate report
            self.print_step(2, total_steps, "Generate RMC Tuscan Report (Intermediate)")
            rmc_tuscan_df = self.execute_sql_query(self.rmc_tuscan_sql, "rmc_tuscan.sql")
            self.export_to_excel(rmc_tuscan_df, self.rmc_tuscan_xlsx, "RMC Tuscan Report")
            
            # Step 3: Convert intermediate Excel report to Parquet
            self.print_step(3, total_steps, "Convert RMC Tuscan Report to Parquet")
            self.excel_to_parquet(self.rmc_tuscan_xlsx, self.rmc_tuscan_parquet, "RMC Tuscan Report")
            
            # Step 4: Execute rmc_tuscan_masterfile.sql
            self.print_step(4, total_steps, "Generate RMC Masterfile Report")
            masterfile_df = self.execute_sql_query(self.rmc_masterfile_sql, "rmc_tuscan_masterfile.sql")
            self.export_to_excel(masterfile_df, self.rmc_masterfile_xlsx, "RMC Masterfile Report")
            
            # Step 5: Execute rmc_tuscan_IRFS9.sql
            self.print_step(5, total_steps, "Generate RMC IFRS9 Report")
            ifrs9_df = self.execute_sql_query(self.rmc_ifrs9_sql, "rmc_tuscan_IRFS9.sql")
            self.export_to_excel(ifrs9_df, self.rmc_ifrs9_xlsx, "RMC IFRS9 Report")
            
            # Pipeline complete
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            print("\n" + "="*80)
            print("PIPELINE COMPLETED SUCCESSFULLY!")
            print("="*80)
            print(f"\nEnd time: {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"Duration: {duration:.2f} seconds")
            print("\nGenerated Files:")
            file_num = 1
            print(f"  {file_num}. {self.loan_tape_parquet}")
            file_num += 1
            print(f"  {file_num}. {self.security_tape_parquet}")
            file_num += 1
            if self.risk_info_xlsx:
                print(f"  {file_num}. {self.risk_info_parquet}")
                file_num += 1
            if self.sic_code_xlsx:
                print(f"  {file_num}. {self.sic_code_parquet}")
                file_num += 1
            print(f"  {file_num}. {self.rmc_tuscan_parquet}")
            file_num += 1
            print(f"  {file_num}. {self.rmc_tuscan_xlsx}")
            file_num += 1
            print(f"  {file_num}. {self.rmc_masterfile_xlsx}")
            file_num += 1
            print(f"  {file_num}. {self.rmc_ifrs9_xlsx}")
            print("\n✓ All reports generated successfully!\n")
            
            return True
            
        except Exception as e:
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            print("\n" + "="*80)
            print("PIPELINE FAILED!")
            print("="*80)
            print(f"\nError: {e}")
            print(f"\nDuration before failure: {duration:.2f} seconds")
            print("\nPlease check the error message above and fix any issues.\n")
            
            return False


def print_usage():
    """Print usage information"""
    print(__doc__)
    print("\nExamples:")
    print("  python generate_rmc_reports.py loan_tape.csv security_tape.csv")
    print("  python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv")
    print("\nRequired Files:")
    print("  - tuscan_queries/rmc_tuscan.sql")
    print("  - tuscan_queries/rmc_tuscan_masterfile.sql")
    print("  - tuscan_queries/rmc_tuscan_IRFS9.sql")
    print("\nOutput Files:")
    print("  - parquet_files/loan_tape.parquet")
    print("  - parquet_files/security_tape.parquet")
    print("  - parquet_files/rmc_tuscan.parquet")
    print("  - output_files/mm-yyyy/rmc_tuscan_report.xlsx")
    print("  - output_files/mm-yyyy/rmc_masterfile_report.xlsx")
    print("  - output_files/mm-yyyy/rmc_ifrs9_report.xlsx")
    print("\nNote: Reports are organized by current month/year (mm-yyyy) when script runs")


def main():
    """Main entry point"""
    if len(sys.argv) != 3:
        print("Error: Invalid number of arguments\n")
        print_usage()
        sys.exit(1)
    
    if sys.argv[1] in ['--help', '-h']:
        print_usage()
        sys.exit(0)
    
    loan_tape_csv = sys.argv[1]
    security_tape_csv = sys.argv[2]
    
    # Create and run pipeline
    pipeline = RMCReportPipeline(loan_tape_csv, security_tape_csv)
    success = pipeline.run()
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()

