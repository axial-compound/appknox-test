"""
Export SQL query results to multiple formats (Excel, CSV, Parquet)
"""
import duckdb
import pandas as pd
import sys
import os
from datetime import datetime

def export_query(sql_file, output_file=None, output_format=None):
    """
    Execute SQL query and export results to specified format
    
    Args:
        sql_file: Path to SQL file containing the query
        output_file: Output file path (optional, auto-generated if not provided)
        output_format: Output format: 'xlsx', 'csv', 'parquet' (auto-detected from extension if not provided)
    
    Returns:
        Path to the created file
    """
    if not os.path.exists(sql_file):
        raise FileNotFoundError(f"SQL file not found: {sql_file}")
    
    # Auto-detect format from output file if not specified
    if output_format is None and output_file is not None:
        ext = os.path.splitext(output_file)[1].lower()
        format_map = {'.xlsx': 'xlsx', '.csv': 'csv', '.parquet': 'parquet'}
        output_format = format_map.get(ext, 'xlsx')
    elif output_format is None:
        output_format = 'xlsx'  # Default to Excel
    
    # Generate output filename if not provided
    if output_file is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        base_name = os.path.splitext(os.path.basename(sql_file))[0]
        extensions = {'xlsx': '.xlsx', 'csv': '.csv', 'parquet': '.parquet'}
        output_file = f"{base_name}_{timestamp}{extensions[output_format]}"
    
    print(f"Reading SQL query from: {sql_file}")
    
    # Read SQL query
    with open(sql_file, 'r') as f:
        query = f.read()
    
    print(f"Executing query...")
    
    # Create DuckDB connection and execute query
    con = duckdb.connect()
    try:
        df = con.execute(query).fetchdf()
        
        print(f"  - Rows retrieved: {len(df):,}")
        print(f"  - Columns: {len(df.columns)}")
        
        # Export based on format
        print(f"\nExporting to {output_format.upper()}: {output_file}")
        
        if output_format == 'xlsx':
            export_to_excel(df, output_file)
        elif output_format == 'csv':
            export_to_csv(df, output_file)
        elif output_format == 'parquet':
            export_to_parquet(df, output_file)
        else:
            raise ValueError(f"Unsupported format: {output_format}")
        
        # Get file size
        file_size = os.path.getsize(output_file)
        
        print(f"\n✓ Export complete!")
        print(f"  File: {output_file}")
        print(f"  Format: {output_format.upper()}")
        print(f"  Size: {file_size:,} bytes ({file_size/1024:.2f} KB)")
        print(f"  Rows: {len(df):,}")
        print(f"  Columns: {len(df.columns)}")
        
        return output_file
        
    except Exception as e:
        print(f"Error: {e}")
        raise
    finally:
        con.close()

def export_to_excel(df, output_file):
    """Export DataFrame to Excel with formatting"""
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Data', index=False)
        
        # Get the worksheet
        worksheet = writer.sheets['Data']
        
        # Auto-adjust column widths
        from openpyxl.utils import get_column_letter
        for idx, col in enumerate(df.columns, 1):
            try:
                # Calculate max length
                max_length = max(
                    df[col].astype(str).apply(len).max(),
                    len(str(col))
                )
                # Set width (with reasonable limits)
                adjusted_width = min(max_length + 2, 50)
                column_letter = get_column_letter(idx)
                worksheet.column_dimensions[column_letter].width = adjusted_width
            except:
                pass

def export_to_csv(df, output_file):
    """Export DataFrame to CSV"""
    df.to_csv(output_file, index=False, encoding='utf-8')

def export_to_parquet(df, output_file):
    """Export DataFrame to Parquet"""
    df.to_parquet(output_file, engine='pyarrow', compression='snappy', index=False)

def main():
    if len(sys.argv) < 2:
        print("Export SQL query results to Excel, CSV, or Parquet format")
        print("\nUsage: python export_query_results.py <sql_file> [output_file] [format]")
        print("\nFormats: xlsx (default), csv, parquet")
        print("\nExamples:")
        print("  # Export to Excel (auto-generated filename)")
        print("  python export_query_results.py tuscan_queries/rmc_tuscan_parquet.sql")
        print("")
        print("  # Export to Excel (specified filename)")
        print("  python export_query_results.py tuscan_queries/rmc_tuscan_parquet.sql report.xlsx")
        print("")
        print("  # Export to CSV")
        print("  python export_query_results.py tuscan_queries/rmc_tuscan_parquet.sql report.csv")
        print("")
        print("  # Export to Parquet")
        print("  python export_query_results.py tuscan_queries/rmc_tuscan_parquet.sql report.parquet")
        print("")
        print("  # Specify format explicitly")
        print("  python export_query_results.py tuscan_queries/rmc_tuscan_parquet.sql output.xlsx xlsx")
        sys.exit(1)
    
    sql_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    output_format = sys.argv[3] if len(sys.argv) > 3 else None
    
    export_query(sql_file, output_file, output_format)

if __name__ == "__main__":
    main()

