# RMC Reports Pipeline - Quick Reference

## One-Line Command

```bash
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

## What It Does

Converts 2 CSV files → Generates 3 Excel reports + 3 Parquet files in < 1 second

## Input Files Required

1. **loan_tape.csv** (loan-level data) **[Required]**
2. **security_tape.csv** (collateral data) **[Required]**

**Optional (auto-detected):**
3. **risk_info.xlsx** (risk information)
4. **sic_code.xlsx** (SIC code mappings)

## Output Files Generated

### Parquet Files (for queries)
1. `parquet_files/loan_tape.parquet`
2. `parquet_files/security_tape.parquet`
3. `parquet_files/risk_info.parquet` (if Excel present)
4. `parquet_files/sic_code.parquet` (if Excel present)
5. `parquet_files/rmc_tuscan.parquet`

### Excel Reports (for users)
4. `output_files/mm-yyyy/rmc_tuscan_report.xlsx` - 104 columns
5. `output_files/mm-yyyy/rmc_masterfile_report.xlsx` - 124 columns (★ Main Report)
6. `output_files/mm-yyyy/rmc_ifrs9_report.xlsx` - 48 columns (IFRS9 Compliance)

**Note:** Reports are organized by current month/year (mm-yyyy) when the script runs.

**Total Generated:** 5 parquet files + 3 Excel reports

## Pipeline Flow

```
Step 1: CSV & Excel → Parquet
   loan_tape.csv ────────────→ loan_tape.parquet
   security_tape.csv ────────→ security_tape.parquet
   risk_info.xlsx ───────────→ risk_info.parquet (optional)
   sic_code.xlsx ────────────→ sic_code.parquet (optional)

Step 2: Generate Tuscan Report
   loan_tape.parquet + security_tape.parquet → rmc_tuscan_report.xlsx (mm-yyyy/)

Step 3: Tuscan Report → Parquet
   rmc_tuscan_report.xlsx ───→ rmc_tuscan.parquet

Step 4: Generate Masterfile
   rmc_tuscan.parquet + loan_tape.parquet → rmc_masterfile_report.xlsx (mm-yyyy/)

Step 5: Generate IFRS9
   rmc_tuscan.parquet + loan_tape.parquet → rmc_ifrs9_report.xlsx (mm-yyyy/)
```

## Key Features

✅ **Automated** - One command, 5 steps  
✅ **Fast** - Completes in < 1 second  
✅ **Comprehensive** - 3 different report types  
✅ **Efficient** - Uses columnar Parquet format  
✅ **Error Handling** - Validates inputs and provides clear messages  
✅ **Repeatable** - Same inputs = same outputs  

## Common Commands

```bash
# Basic usage
python generate_rmc_reports.py loan_tape.csv security_tape.csv

# With full paths
python generate_rmc_reports.py /path/to/loan_tape.csv /path/to/security_tape.csv

# Show help
python generate_rmc_reports.py --help

# Run from anywhere (if in PATH)
cd ~/Documents
python /path/to/parquet-retrieval/generate_rmc_reports.py data/loan.csv data/security.csv
```

## Expected Output

```
================================================================================
RMC TUSCAN REPORT PIPELINE
================================================================================
Start time: 2025-10-31 10:36:51

Validating input files...
✓ All input files validated

================================================================================
STEP 1/5: Convert input CSV files to Parquet
================================================================================
✓ Converted Loan Tape CSV (194 rows, 119 columns)
✓ Converted Security Tape CSV (484 rows, 44 columns)

================================================================================
STEP 2/5: Generate RMC Tuscan Report (Intermediate)
================================================================================
✓ Query executed successfully (108 rows, 104 columns)
✓ Excel file created (62.72 KB)

================================================================================
STEP 3/5: Convert RMC Tuscan Report to Parquet
================================================================================
✓ Parquet file created (108 rows, 104 columns)

================================================================================
STEP 4/5: Generate RMC Masterfile Report
================================================================================
✓ Query executed successfully (108 rows, 124 columns)
✓ Excel file created (74.82 KB)

================================================================================
STEP 5/5: Generate RMC IFRS9 Report
================================================================================
✓ Query executed successfully (108 rows, 48 columns)
✓ Excel file created (27.45 KB)

================================================================================
PIPELINE COMPLETED SUCCESSFULLY!
================================================================================
Duration: 0.97 seconds
✓ All reports generated successfully!
```

## Report Descriptions

### 1. RMC Tuscan Report
**File:** `output_files/mm-yyyy/rmc_tuscan_report.xlsx`  
**Purpose:** Intermediate analytical dataset  
**Columns:** 104  
**Use:** Foundation for other reports

### 2. RMC Masterfile Report ⭐
**File:** `output_files/mm-yyyy/rmc_masterfile_report.xlsx`  
**Purpose:** Comprehensive regulatory and management report  
**Columns:** 124  
**Use:** Main report for RMC meetings, regulatory submissions

**Key Sections:**
- Borrower information
- Loan details and dates
- Interest rates and LTV calculations
- Risk grades and categories
- Exposure size bands
- Security information
- Credit scores

### 3. RMC IFRS9 Report
**File:** `output_files/mm-yyyy/rmc_ifrs9_report.xlsx`  
**Purpose:** IFRS9 accounting compliance  
**Columns:** 48  
**Use:** Financial reporting, audit trail

**Key Sections:**
- Contractual balances
- Interest rate schedules
- Security type mappings
- Risk grade alignment
- Deduction calculations

## Troubleshooting

| Issue | Solution |
|-------|----------|
| File not found | Check file paths are correct |
| SQL error | Verify parquet files exist in `parquet_files/` |
| Binding error (sic_code) | Run: `python diagnose_environment.py` |
| 0 rows returned | Check date filter in SQL matches your data |
| Permission denied | Ensure write access to `output_files/` directory |

**Quick diagnostic:**
```bash
python diagnose_environment.py
```

**Quick fix for binding errors:**
```bash
# Ensure Excel files are present, then:
rm parquet_files/*.parquet
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

## Quick Checks

```bash
# Check if pipeline is installed correctly
python generate_rmc_reports.py --help

# View generated files
ls -lh output_files/
ls -lh parquet_files/

# Check report contents quickly
head -n 5 output_files/rmc_masterfile_report.xlsx  # Won't work - binary
# Instead, open in Excel or:
python -c "import pandas as pd; print(pd.read_excel('output_files/rmc_masterfile_report.xlsx').head())"

# Query parquet files directly
python query_parquet.py -f parquet_files/rmc_tuscan.parquet "SELECT COUNT(*) FROM 'parquet_files/rmc_tuscan.parquet'"
```

## Performance Benchmarks

| Dataset Size | Rows | Execution Time |
|--------------|------|----------------|
| Small | 50 loans | 0.5 seconds |
| Medium | 200 loans | 1.0 seconds |
| Large | 1,000 loans | 3-5 seconds |
| Very Large | 5,000+ loans | 10-20 seconds |

## File Size Expectations

| Report Type | Typical Size |
|-------------|--------------|
| Tuscan | 60-70 KB |
| Masterfile | 70-80 KB |
| IFRS9 | 25-30 KB |

## Dependencies

```bash
pip install pandas pyarrow openpyxl duckdb
```

## Directory Structure

```
parquet-retrieval/
├── generate_rmc_reports.py        ← Main pipeline script
├── input_files/tuscan/
│   ├── loan_tape.csv
│   └── security_tape.csv
├── tuscan_queries/
│   ├── rmc_tuscan.sql
│   ├── rmc_tuscan_masterfile.sql
│   └── rmc_tuscan_IRFS9.sql
├── parquet_files/                 ← Generated
│   ├── loan_tape.parquet
│   ├── security_tape.parquet
│   └── rmc_tuscan.parquet
└── output_files/                  ← Generated (organized by mm-yyyy)
    └── 09-2025/                   ← Date-based folders
        ├── rmc_tuscan_report.xlsx
        ├── rmc_masterfile_report.xlsx
        └── rmc_ifrs9_report.xlsx
```

## Need More Help?

- Full documentation: `PIPELINE_USER_GUIDE.md`
- Project overview: `README.md`

---

**Quick Tip:** Bookmark this file for fast reference! 📌

