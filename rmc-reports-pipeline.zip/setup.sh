#!/bin/bash

###############################################################################
# RMC Reports Pipeline - Setup Script
# 
# This script sets up the environment and installs dependencies
###############################################################################

echo "=========================================="
echo "RMC Reports Pipeline - Setup"
echo "=========================================="
echo ""

# Check Python version
echo "Checking Python installation..."
if command -v python3 &> /dev/null; then
    PYTHON_CMD=python3
    PIP_CMD=pip3
elif command -v python &> /dev/null; then
    PYTHON_CMD=python
    PIP_CMD=pip
else
    echo "❌ Error: Python is not installed!"
    echo "Please install Python 3.7+ from https://www.python.org/downloads/"
    exit 1
fi

# Get Python version
PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | awk '{print $2}')
echo "✓ Found Python $PYTHON_VERSION"

# Check Python version is >= 3.7
PYTHON_MAJOR=$($PYTHON_CMD -c 'import sys; print(sys.version_info.major)')
PYTHON_MINOR=$($PYTHON_CMD -c 'import sys; print(sys.version_info.minor)')

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 7 ]); then
    echo "❌ Error: Python 3.7 or higher is required!"
    echo "Current version: $PYTHON_VERSION"
    exit 1
fi

echo ""
echo "Installing dependencies..."
echo ""

# Install requirements
if $PIP_CMD install -r requirements.txt; then
    echo ""
    echo "=========================================="
    echo "✓ Setup completed successfully!"
    echo "=========================================="
    echo ""
    echo "To test the installation, run:"
    echo "  $PYTHON_CMD generate_rmc_reports.py --help"
    echo ""
    echo "To generate reports, run:"
    echo "  $PYTHON_CMD generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv"
    echo ""
else
    echo ""
    echo "=========================================="
    echo "❌ Setup failed!"
    echo "=========================================="
    echo ""
    echo "Try running manually:"
    echo "  $PIP_CMD install --user -r requirements.txt"
    echo ""
    exit 1
fi

