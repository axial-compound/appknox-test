# RMC Tuscan Reports Pipeline - User Guide

## Overview

The `generate_rmc_reports.py` script automates the complete process of generating RMC (Risk Management Committee) reports for Tuscan bridging finance portfolio.

## Purpose

This pipeline consolidates multiple manual steps into a single automated workflow:
1. Converts raw CSV data to efficient Parquet format
2. Generates intermediate analytical reports
3. Produces final regulatory and management reports

## Requirements

### Software Dependencies
- Python 3.7+
- pandas
- pyarrow
- openpyxl
- duckdb

### Required Files
- `tuscan_queries/rmc_tuscan.sql` - Main Tuscan report query
- `tuscan_queries/rmc_tuscan_masterfile.sql` - Comprehensive masterfile query
- `tuscan_queries/rmc_tuscan_IRFS9.sql` - IFRS9 compliance query

## Usage

### Basic Command

```bash
python generate_rmc_reports.py <loan_tape.csv> <security_tape.csv>
```

### Examples

```bash
# Using files from tuscan input directory
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv

# Using files from current directory
python generate_rmc_reports.py loan_tape.csv security_tape.csv

# View help
python generate_rmc_reports.py --help
```

## Pipeline Steps

### Step 1: Convert Input Files to Parquet
**Purpose:** Convert raw CSV and Excel data to efficient columnar format

**Input:**
- `loan_tape.csv` - Loan-level details (119 columns) **[Required]**
- `security_tape.csv` - Security/collateral information (44 columns) **[Required]**
- `risk_info.xlsx` - Risk information (16 columns, ~34K rows) **[Optional]**
- `sic_code.xlsx` - SIC code mappings (12 columns, ~1K rows) **[Optional]**

**Output:**
- `parquet_files/loan_tape.parquet`
- `parquet_files/security_tape.parquet`
- `parquet_files/risk_info.parquet` (if Excel file present)
- `parquet_files/sic_code.parquet` (if Excel file present)

**Benefits:**
- 50-70% smaller file size
- 10-100x faster query performance
- Column-based compression
- Strongly typed data

### Step 2: Generate RMC Tuscan Report (Intermediate)
**Purpose:** Create comprehensive analytical dataset

**Process:**
- Executes `rmc_tuscan.sql`
- Joins loan and security data
- Performs complex aggregations and transformations
- Applies business rules

**Output:**
- `output_files/mm-yyyy/rmc_tuscan_report.xlsx` (104 columns, ~63 KB)

**Note:** Reports are automatically organized by date (mm-yyyy format) based on the **current month/year when the script runs** (not the report_date from the data).

**Key Metrics:**
- Security valuations
- LTV calculations
- Risk classifications
- Portfolio distributions

### Step 3: Convert RMC Tuscan Report to Parquet
**Purpose:** Create queryable analytical dataset

**Process:**
- Reads Excel report from Step 2
- Converts to Parquet format
- Enables downstream SQL queries

**Output:**
- `parquet_files/rmc_tuscan.parquet` (~97 KB)

**Use Cases:**
- Source for masterfile report
- Source for IFRS9 report
- Ad-hoc analysis queries
- Data validation

### Step 4: Generate RMC Masterfile Report
**Purpose:** Comprehensive regulatory and management report

**Process:**
- Executes `rmc_tuscan_masterfile.sql`
- Reads from `rmc_tuscan.parquet` and `loan_tape.parquet`
- Applies extensive business logic
- Calculates 124 derived fields

**Output:**
- `output_files/mm-yyyy/rmc_masterfile_report.xlsx` (124 columns, ~75 KB)

**Key Features:**
- Complete borrower information
- Detailed LTV bands and classifications
- Risk grade categorizations
- Exposure size bands
- Asset type classifications
- Credit scores integration

### Step 5: Generate RMC IFRS9 Report
**Purpose:** IFRS9 accounting compliance report

**Process:**
- Executes `rmc_tuscan_IRFS9.sql`
- Focuses on financial reporting metrics
- Includes deduction calculations
- Provides credit score history

**Output:**
- `output_files/mm-yyyy/rmc_ifrs9_report.xlsx` (48 columns, ~27 KB)

**Key Features:**
- Contractual balance with first charge
- Interest rate schedules
- Security type mappings
- Risk grade alignment
- Deduction period calculations
- Credit scoring (Delphi)

## Input File Requirements

### Loan Tape CSV
**Required Columns:**
- `loan_id` - Unique loan identifier
- `report_date` - Reporting date
- `loan_start_date` - Loan origination date
- `current_gross_loan` - Current balance
- `original_credit_score` - Credit score at origination
- Plus ~110 additional analytical fields

**Expected Format:**
- CSV with headers
- Date fields in YYYY-MM-DD format
- Numeric fields without currency symbols
- Text encoding: UTF-8

### Security Tape CSV
**Required Columns:**
- `loan_id` - Links to loan_tape
- `security_id` - Unique security identifier
- `report_date` - Reporting date
- `security_status` - Status (e.g., 'Held')
- `latest_vpv` or `latest_mv1` - Current valuations
- Plus ~40 additional fields

**Expected Format:**
- CSV with headers
- Consistent loan_id references
- Numeric values for valuations
- Text encoding: UTF-8

## Output Files

### Generated Parquet Files

| File | Size | Rows | Columns | Description |
|------|------|------|---------|-------------|
| `loan_tape.parquet` | ~139 KB | 194 | 119 | Loan-level master data |
| `security_tape.parquet` | ~76 KB | 484 | 44 | Security/collateral data |
| `risk_info.parquet` | ~641 KB | 33,986 | 16 | Risk information (optional) |
| `sic_code.parquet` | ~75 KB | 1,025 | 12 | SIC code mappings (optional) |
| `rmc_tuscan.parquet` | ~97 KB | 108 | 104 | Analytical dataset |

### Generated Excel Reports

| File | Size | Rows | Columns | Description |
|------|------|------|---------|-------------|
| `rmc_tuscan_report.xlsx` | ~63 KB | 108 | 104 | Intermediate analytical report |
| `rmc_masterfile_report.xlsx` | ~75 KB | 108 | 124 | Comprehensive masterfile |
| `rmc_ifrs9_report.xlsx` | ~27 KB | 108 | 48 | IFRS9 compliance report |

**Note:** Reports are stored in `output_files/mm-yyyy/` folders based on the current month/year when the script runs.

## Performance

**Typical Execution Time:** < 1 second

**Benchmark (194 loans, 484 securities):**
- Step 1: 0.2 seconds (CSV → Parquet conversion)
- Step 2: 0.2 seconds (RMC Tuscan SQL query)
- Step 3: 0.1 seconds (Excel → Parquet conversion)
- Step 4: 0.2 seconds (Masterfile SQL query)
- Step 5: 0.2 seconds (IFRS9 SQL query)
- **Total: ~1 second**

## Error Handling

The pipeline includes comprehensive error handling:

### Validation Checks
- ✓ Input files exist
- ✓ SQL query files exist
- ✓ Output directories are created
- ✓ Data types are valid

### Common Errors

**Error:** `FileNotFoundError: Loan tape CSV not found`
**Solution:** Verify the path to loan_tape.csv is correct

**Error:** `FileNotFoundError: SQL file not found`
**Solution:** Ensure all SQL files are in `tuscan_queries/` directory

**Error:** `Binder Error: Column not found`
**Solution:** Check that CSV column names match SQL query expectations

**Error:** `Query execution failed`
**Solution:** Review SQL syntax and ensure Parquet files are valid

## Advanced Usage

### Custom Date Filtering

To query a specific reporting date, modify the SQL files' WHERE clause:

```sql
-- Change from:
WHERE r.reporting_date = (SELECT MAX(reporting_date) FROM 'parquet_files/rmc_tuscan.parquet')

-- To:
WHERE r.reporting_date = '2025-10-30'
```

### Running Individual Steps

You can run individual components manually:

```bash
# Convert CSV to Parquet only
python csv_to_parquet.py loan_tape.csv

# Run specific SQL query
python query_parquet.py -f parquet_files/rmc_tuscan.parquet tuscan_queries/rmc_masterfile.sql

# Export query results
python export_query_results.py tuscan_queries/rmc_masterfile.sql output.xlsx
```

### Batch Processing

Process multiple months of data:

```bash
#!/bin/bash
for month in 2024-{01..12}; do
    python generate_rmc_reports.py \
        data/${month}_loan_tape.csv \
        data/${month}_security_tape.csv
    
    # Rename outputs with month suffix
    mv output_files/rmc_masterfile_report.xlsx \
       output_files/rmc_masterfile_${month}.xlsx
done
```

## Integration

### Scheduled Execution

Add to crontab for monthly execution:

```cron
# Run on the 1st of each month at 6 AM
0 6 1 * * cd /path/to/parquet-retrieval && python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

### Python Integration

```python
from generate_rmc_reports import RMCReportPipeline

# Create pipeline instance
pipeline = RMCReportPipeline(
    'data/loan_tape.csv',
    'data/security_tape.csv'
)

# Run pipeline
success = pipeline.run()

if success:
    print("Reports generated successfully!")
else:
    print("Pipeline failed. Check logs for details.")
```

## Troubleshooting

### Issue: Column width warnings

**Symptom:** Warnings during Excel export
```
Warning: Could not adjust width for column 104: [
```

**Impact:** None - file is still created correctly
**Cause:** Excel column letter calculation for columns beyond Z
**Status:** Handled gracefully, doesn't affect output

### Issue: No rows returned

**Symptom:** Query returns 0 rows
**Cause:** Date filter doesn't match data
**Solution:** Check available dates:

```sql
SELECT DISTINCT reporting_date 
FROM 'parquet_files/rmc_tuscan.parquet' 
ORDER BY reporting_date DESC;
```

### Issue: Memory errors with large files

**Symptom:** Out of memory errors
**Solution:** Process in chunks or increase available RAM

## Maintenance

### Updating SQL Queries

1. Edit SQL file in `tuscan_queries/` directory
2. Test query manually first:
   ```bash
   python query_parquet.py -f parquet_files/rmc_tuscan.parquet tuscan_queries/your_query.sql
   ```
3. Run full pipeline to verify integration

### Adding New Reports

1. Create new SQL file in `tuscan_queries/`
2. Add step to pipeline in `generate_rmc_reports.py`
3. Define output path and export logic
4. Update documentation

## Support

For issues or questions:
1. Check this documentation
2. Review SQL query files for business logic
3. Examine error messages in pipeline output
4. Verify input data formats

## Version History

- **v1.0** (2025-10-31): Initial pipeline implementation
  - 5-step automated workflow
  - Support for loan_tape and security_tape inputs
  - Three output reports: Tuscan, Masterfile, IFRS9
  - DuckDB-based SQL queries
  - Comprehensive error handling

## Related Documentation

- `README.md` - Project overview and setup
- `QUICK_REFERENCE.md` - Quick reference guide

---

**Last Updated:** October 31, 2025  
**Pipeline Version:** 1.0  
**Maintained By:** RMC Analytics Team

