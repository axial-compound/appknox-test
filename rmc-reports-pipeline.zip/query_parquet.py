"""
Run SQL queries against Parquet files using DuckDB
"""
import duckdb
import sys
import os

def run_example_queries(parquet_file='sample_data.parquet'):
    """
    Run various example SQL queries against a Parquet file
    """
    print(f"Running SQL queries against: {parquet_file}\n")
    print("=" * 80)
    
    # Create a DuckDB connection
    con = duckdb.connect()
    
    # Example 1: Basic SELECT with LIMIT
    print("\n1. Basic SELECT - First 5 employees")
    print("-" * 80)
    query1 = f"""
    SELECT employee_id, full_name, department, salary, hire_date
    FROM '{parquet_file}'
    LIMIT 5
    """
    result1 = con.execute(query1).fetchdf()
    print(result1.to_string(index=False))
    
    # Example 2: Filtering and sorting
    print("\n\n2. High earners in Engineering (salary > $100k)")
    print("-" * 80)
    query2 = f"""
    SELECT full_name, department, salary, office_location
    FROM '{parquet_file}'
    WHERE department = 'Engineering' AND salary > 100000
    ORDER BY salary DESC
    LIMIT 10
    """
    result2 = con.execute(query2).fetchdf()
    print(result2.to_string(index=False))
    
    # Example 3: Aggregation with GROUP BY
    print("\n\n3. Average salary by department")
    print("-" * 80)
    query3 = f"""
    SELECT 
        department,
        COUNT(*) as employee_count,
        ROUND(AVG(salary), 2) as avg_salary,
        ROUND(MIN(salary), 2) as min_salary,
        ROUND(MAX(salary), 2) as max_salary
    FROM '{parquet_file}'
    GROUP BY department
    ORDER BY avg_salary DESC
    """
    result3 = con.execute(query3).fetchdf()
    print(result3.to_string(index=False))
    
    # Example 4: Date filtering
    print("\n\n4. Employees hired in the last 2 years")
    print("-" * 80)
    query4 = f"""
    SELECT full_name, department, hire_date, office_location
    FROM '{parquet_file}'
    WHERE hire_date >= CURRENT_DATE - INTERVAL '2 years'
    ORDER BY hire_date DESC
    LIMIT 10
    """
    result4 = con.execute(query4).fetchdf()
    print(result4.to_string(index=False))
    
    # Example 5: Multiple conditions and Boolean filtering
    print("\n\n5. Active employees in Remote locations with high performance")
    print("-" * 80)
    query5 = f"""
    SELECT full_name, department, salary, performance_score, office_location
    FROM '{parquet_file}'
    WHERE is_active = true 
      AND office_location = 'Remote'
      AND performance_score >= 4
    ORDER BY performance_score DESC, salary DESC
    LIMIT 10
    """
    result5 = con.execute(query5).fetchdf()
    print(result5.to_string(index=False))
    
    # Example 6: Statistical analysis
    print("\n\n6. Office location distribution and stats")
    print("-" * 80)
    query6 = f"""
    SELECT 
        office_location,
        COUNT(*) as total_employees,
        COUNT(*) * 100.0 / SUM(COUNT(*)) OVER () as percentage,
        ROUND(AVG(salary), 2) as avg_salary,
        COUNT(CASE WHEN is_active THEN 1 END) as active_employees
    FROM '{parquet_file}'
    GROUP BY office_location
    ORDER BY total_employees DESC
    """
    result6 = con.execute(query6).fetchdf()
    print(result6.to_string(index=False))
    
    # Example 7: Get schema information
    print("\n\n7. Parquet file schema")
    print("-" * 80)
    query7 = f"DESCRIBE SELECT * FROM '{parquet_file}'"
    result7 = con.execute(query7).fetchdf()
    print(result7.to_string(index=False))
    
    # Example 8: Count statistics
    print("\n\n8. Overall statistics")
    print("-" * 80)
    query8 = f"""
    SELECT 
        COUNT(*) as total_records,
        COUNT(DISTINCT department) as unique_departments,
        COUNT(DISTINCT office_location) as unique_locations,
        ROUND(AVG(salary), 2) as overall_avg_salary,
        COUNT(CASE WHEN is_active THEN 1 END) as active_count,
        COUNT(CASE WHEN NOT is_active THEN 1 END) as inactive_count
    FROM '{parquet_file}'
    """
    result8 = con.execute(query8).fetchdf()
    print(result8.to_string(index=False))
    
    print("\n" + "=" * 80)
    print("✓ All queries completed successfully!")
    
    con.close()

def run_custom_query(parquet_file, query):
    """
    Run a custom SQL query against a Parquet file
    """
    con = duckdb.connect()
    try:
        result = con.execute(query).fetchdf()
        print(result.to_string(index=False))
    except Exception as e:
        print(f"Error executing query: {e}")
    finally:
        con.close()

def run_query_from_file(parquet_file, sql_file):
    """
    Run SQL query from a file against a Parquet file
    
    Args:
        parquet_file: Path to the Parquet file to query
        sql_file: Path to the SQL file containing the query
    """
    if not os.path.exists(sql_file):
        print(f"Error: SQL file not found: {sql_file}")
        sys.exit(1)
    
    if not os.path.exists(parquet_file):
        print(f"Error: Parquet file not found: {parquet_file}")
        sys.exit(1)
    
    print(f"Reading SQL query from: {sql_file}")
    print(f"Querying Parquet file: {parquet_file}")
    print("=" * 80)
    
    with open(sql_file, 'r') as f:
        query = f.read().strip()
    
    if not query:
        print("Error: SQL file is empty")
        sys.exit(1)
    
    print(f"\nExecuting query:\n{query}\n")
    print("-" * 80)
    
    con = duckdb.connect()
    try:
        result = con.execute(query).fetchdf()
        print(result.to_string(index=False))
        print(f"\n✓ Query completed successfully! ({len(result)} rows returned)")
    except Exception as e:
        print(f"Error executing query: {e}")
        sys.exit(1)
    finally:
        con.close()

def print_usage():
    """Print usage information"""
    print("Usage:")
    print("  python query_parquet.py                                    # Run example queries")
    print("  python query_parquet.py <parquet_file>                     # Run examples on specific file")
    print("  python query_parquet.py --custom <parquet_file> '<query>'  # Run inline query")
    print("  python query_parquet.py --file <parquet_file> <sql_file>   # Run query from file")
    print("  python query_parquet.py -f <parquet_file> <sql_file>       # Short version")
    print("\nExamples:")
    print("  python query_parquet.py")
    print("  python query_parquet.py my_data.parquet")
    print("  python query_parquet.py --custom sample_data.parquet 'SELECT * FROM sample_data.parquet LIMIT 10'")
    print("  python query_parquet.py --file sample_data.parquet my_query.sql")
    print("  python query_parquet.py -f sample_data.parquet my_query.sql")

def main():
    if len(sys.argv) < 2:
        print("Running example queries with default file (sample_data.parquet)...\n")
        run_example_queries()
    elif sys.argv[1] in ['--help', '-h']:
        print_usage()
    elif sys.argv[1] == '--custom':
        if len(sys.argv) < 4:
            print("Error: --custom requires parquet file and SQL query")
            print()
            print_usage()
            sys.exit(1)
        parquet_file = sys.argv[2]
        query = sys.argv[3]
        run_custom_query(parquet_file, query)
    elif sys.argv[1] in ['--file', '-f']:
        if len(sys.argv) < 4:
            print("Error: --file requires parquet file and SQL file paths")
            print()
            print_usage()
            sys.exit(1)
        parquet_file = sys.argv[2]
        sql_file = sys.argv[3]
        run_query_from_file(parquet_file, sql_file)
    else:
        parquet_file = sys.argv[1]
        run_example_queries(parquet_file)

if __name__ == "__main__":
    main()

