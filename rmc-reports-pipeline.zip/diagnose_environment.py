#!/usr/bin/env python3
"""
Diagnostic script to check the RMC pipeline environment
Helps identify missing files or schema issues
"""

import os
import sys
from pathlib import Path

def print_section(title):
    """Print a formatted section header"""
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}")

def check_file_exists(filepath, file_type="File"):
    """Check if a file exists and print status"""
    exists = os.path.exists(filepath)
    status = "✓" if exists else "✗"
    size = f"({os.path.getsize(filepath):,} bytes)" if exists else "(missing)"
    print(f"{status} {file_type}: {filepath} {size}")
    return exists

def check_parquet_schema(filepath):
    """Check parquet file schema and look for sic_code column"""
    try:
        import pandas as pd
        df = pd.read_parquet(filepath)
        print(f"    Rows: {len(df):,}, Columns: {len(df.columns)}")
        
        # Check for sic_code column
        sic_cols = [col for col in df.columns if 'sic' in col.lower()]
        if sic_cols:
            print(f"    ✓ SIC-related columns found: {sic_cols}")
        else:
            print(f"    ✗ WARNING: No SIC-related columns found!")
        
        return True
    except Exception as e:
        print(f"    ✗ ERROR reading parquet: {e}")
        return False

def main():
    """Run diagnostics"""
    print_section("RMC PIPELINE ENVIRONMENT DIAGNOSTICS")
    
    # Check Python environment
    print_section("Python Environment")
    print(f"Python version: {sys.version}")
    print(f"Working directory: {os.getcwd()}")
    
    # Check required packages
    print("\nRequired packages:")
    packages = ['pandas', 'pyarrow', 'openpyxl', 'duckdb']
    for pkg in packages:
        try:
            __import__(pkg)
            print(f"✓ {pkg} installed")
        except ImportError:
            print(f"✗ {pkg} NOT installed")
    
    # Check input files
    print_section("Input Files (Required)")
    req_files_ok = True
    req_files_ok &= check_file_exists("input_files/tuscan/loan_tape.csv", "CSV")
    req_files_ok &= check_file_exists("input_files/tuscan/security_tape.csv", "CSV")
    
    print_section("Input Files (Optional)")
    opt_risk = check_file_exists("input_files/tuscan/risk_info.xlsx", "Excel")
    opt_sic = check_file_exists("input_files/tuscan/sic_code.xlsx", "Excel")
    
    # Check SQL files
    print_section("SQL Query Files")
    sql_files_ok = True
    sql_files_ok &= check_file_exists("tuscan_queries/rmc_tuscan.sql", "SQL")
    sql_files_ok &= check_file_exists("tuscan_queries/rmc_tuscan_masterfile.sql", "SQL")
    sql_files_ok &= check_file_exists("tuscan_queries/rmc_tuscan_IRFS9.sql", "SQL")
    
    # Check generated parquet files
    print_section("Generated Parquet Files")
    
    loan_ok = check_file_exists("parquet_files/loan_tape.parquet", "Parquet")
    sec_ok = check_file_exists("parquet_files/security_tape.parquet", "Parquet")
    risk_ok = check_file_exists("parquet_files/risk_info.parquet", "Parquet")
    sic_ok = check_file_exists("parquet_files/sic_code.parquet", "Parquet")
    
    print("\n" + "-"*70)
    print("Checking rmc_tuscan.parquet schema...")
    print("-"*70)
    
    if check_file_exists("parquet_files/rmc_tuscan.parquet", "Parquet"):
        check_parquet_schema("parquet_files/rmc_tuscan.parquet")
    
    # Diagnosis summary
    print_section("DIAGNOSIS SUMMARY")
    
    issues = []
    
    if not req_files_ok:
        issues.append("❌ Required input CSV files are missing")
    
    if not opt_sic:
        issues.append("⚠️  sic_code.xlsx is missing (optional but needed for sic_code column)")
    
    if not sic_ok:
        issues.append("❌ sic_code.parquet is missing (needed for rmc_tuscan.sql)")
    
    if not check_file_exists("parquet_files/rmc_tuscan.parquet", ""):
        issues.append("❌ rmc_tuscan.parquet is missing (run pipeline to generate)")
    
    if issues:
        print("\n⚠️  ISSUES FOUND:")
        for issue in issues:
            print(f"  {issue}")
        
        print("\n📝 RECOMMENDED ACTIONS:")
        
        if not opt_sic:
            print("  1. Add sic_code.xlsx to input_files/tuscan/")
        
        if not sic_ok or not check_file_exists("parquet_files/rmc_tuscan.parquet", ""):
            print("  2. Delete old parquet files: rm parquet_files/*.parquet")
            print("  3. Re-run the pipeline: python generate_rmc_reports.py \\")
            print("       input_files/tuscan/loan_tape.csv \\")
            print("       input_files/tuscan/security_tape.csv")
        
        print("\n" + "="*70)
        print("  Fix these issues and run the pipeline again")
        print("="*70)
        sys.exit(1)
    else:
        print("\n✅ All checks passed! Environment looks good.")
        print("\n" + "="*70)
        print("  You can run the pipeline")
        print("="*70)
        sys.exit(0)

if __name__ == "__main__":
    main()

