# Sharing This Project

This guide helps you package and share the RMC Reports Pipeline with others.

## What to Share

### Essential Files (Always Include)

**Core Scripts:**
- `generate_rmc_reports.py` - Main pipeline
- `query_parquet.py` - Query tool
- `export_query_results.py` - Export tool

**Setup Files:**
- `requirements.txt` - Python dependencies
- `setup.sh` - Setup script (macOS/Linux)
- `setup.bat` - Setup script (Windows)
- `run_example.sh` - Example runner (macOS/Linux)
- `run_example.bat` - Example runner (Windows)

**Documentation:**
- `README.md` - Project overview
- `INSTALL.md` - Installation guide
- `QUICK_REFERENCE.md` - Quick reference
- `PIPELINE_USER_GUIDE.md` - Complete guide

**SQL Queries:**
- `tuscan_queries/rmc_tuscan.sql`
- `tuscan_queries/rmc_tuscan_masterfile.sql`
- `tuscan_queries/rmc_tuscan_IRFS9.sql`

**Sample Data (Optional but recommended):**
- `input_files/tuscan/loan_tape.csv`
- `input_files/tuscan/security_tape.csv`
- `input_files/tuscan/risk_info.xlsx`
- `input_files/tuscan/sic_code.xlsx`

### Files to Exclude (Auto-generated)

These are automatically generated and should NOT be shared:
- `output_files/*` - Generated reports
- `parquet_files/*.parquet` - Generated parquet files
- `__pycache__/` - Python cache
- `venv/` or `env/` - Virtual environment

## Sharing Methods

### Method 1: ZIP File (Simple)

Create a clean package:

```bash
# Create a zip file excluding generated files
zip -r rmc-reports-pipeline.zip . \
  -x "output_files/*" \
  -x "parquet_files/*.parquet" \
  -x "__pycache__/*" \
  -x "venv/*" \
  -x ".git/*" \
  -x "*.pyc" \
  -x ".DS_Store"
```

Or on Windows using File Explorer:
1. Copy the project folder
2. Delete `output_files/*/` subfolders and `parquet_files/*.parquet` files
3. Right-click → Send to → Compressed (zipped) folder

### Method 2: Git Repository (Recommended)

If using Git:

```bash
# Initialize git repository (if not already done)
git init

# Add all files (respecting .gitignore)
git add .

# Commit
git commit -m "Initial commit: RMC Reports Pipeline"

# Push to GitHub/GitLab/Bitbucket
git remote add origin <your-repository-url>
git push -u origin main
```

Share the repository URL with others. They can clone it:

```bash
git clone <your-repository-url>
cd parquet-retrieval
./setup.sh  # or setup.bat on Windows
```

### Method 3: Cloud Storage (Dropbox, Google Drive, OneDrive)

1. Copy the entire project folder
2. Delete generated folders: `output_files/*/` and `parquet_files/*.parquet`
3. Upload to cloud storage
4. Share the folder link

## Instructions for Recipients

### Quick Start for Recipients

**Provide these simple instructions:**

1. **Download/Extract** the project files

2. **Open terminal/command prompt** and navigate to the project folder:
   ```bash
   cd parquet-retrieval
   ```

3. **Run setup** (one-time):
   
   On macOS/Linux:
   ```bash
   ./setup.sh
   ```
   
   On Windows:
   ```batch
   setup.bat
   ```

4. **Generate reports**:
   ```bash
   python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
   ```

5. **Find reports** in `output_files/mm-yyyy/` folder

### Sample Email/Message Template

```
Hi [Name],

I'm sharing the RMC Reports Pipeline with you. This tool automatically generates 
Tuscan RMC reports from loan and security tape CSV files.

📦 Package: [attached/link to download]

🚀 Quick Start:
1. Extract the files
2. Run setup.sh (Mac/Linux) or setup.bat (Windows)
3. Run: python generate_rmc_reports.py <loan_tape.csv> <security_tape.csv>
4. Check output_files/ for generated reports

📚 Documentation:
- README.md - Quick overview
- INSTALL.md - Detailed installation help
- QUICK_REFERENCE.md - Command examples
- PIPELINE_USER_GUIDE.md - Complete guide

✨ Features:
- Generates 3 reports in < 1 second
- Auto-organizes by month (mm-yyyy folders)
- 124-column masterfile report
- IFRS9 compliance report

Let me know if you need any help!

Best,
[Your Name]
```

## System Requirements

Make sure recipients know the requirements:

### Minimum Requirements
- Python 3.7 or higher
- 200 MB disk space
- Any OS: Windows, macOS, Linux

### Recommended
- Python 3.9 or higher
- 500 MB disk space for larger datasets
- 8 GB RAM (for processing large files)

## Troubleshooting Tips for Recipients

Common issues and solutions to share:

### "Python not found"
**Solution:** Install Python from https://www.python.org/downloads/

### "pip: command not found"
**Solution:** Use `pip3` instead of `pip`, or install pip: `python -m ensurepip`

### "Permission denied" on scripts
**Solution (Mac/Linux):** Run `chmod +x setup.sh run_example.sh`

### Dependencies fail to install
**Solution:** Try: `pip install --user -r requirements.txt`

## Updating the Package

When you make changes:

1. Test everything works:
   ```bash
   python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
   ```

2. Update documentation if needed

3. Create new package (zip/git commit)

4. Increment version number if you're tracking versions

## Security Considerations

**Before sharing:**

1. ✅ Remove any sensitive data from sample CSV files
2. ✅ Check SQL queries don't contain sensitive information
3. ✅ Remove any generated reports with real data
4. ✅ Check no credentials are hardcoded anywhere
5. ✅ Review documentation for company-specific references

## License and Usage

Consider adding a LICENSE file or usage terms if needed for your organization.

---

**Questions?** Update this guide as you discover new best practices for sharing!

