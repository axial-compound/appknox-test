-- ============================================================================
-- Report Name: RMC_TUSCAN_IFRS9 - PARQUET VERSION
-- ============================================================================
-- Original Author: Mithunan Sathiyandra
-- Adapted for: DuckDB + Parquet files
-- Creation date: 02/10/2024
-- Description: RMC IFRS9 Input dataset format for Tuscan
-- 
-- Data Sources:
-- - parquet_files/loan_tape.parquet
-- - parquet_files/rmc_tuscan.parquet
-- ============================================================================

-- Note: DuckDB doesn't support session variables like SQL Server's DECLARE/SET
-- If you need to parameterize transaction_max_date, pass it via your application
-- Default behavior: uses the maximum reporting_date available in the data

WITH 
-- ============================================================================
-- SECTION 1: LATEST SCORES CTE
-- ============================================================================

-- CTE to select the latest credit score per account_id
latest_scores AS (
    SELECT 
        loan_id,
        report_date,
        loan_start_date,
        number_months_deducted,
        original_term,
        original_credit_score,
        current_gross_loan,
        current_maximum_rolled_interest,
        total_interest_rolled,
        amort_type AS deal_type,
        existing_first_charge,  -- Retrieve first charge value
        ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY report_date DESC) AS rn
    FROM 'parquet_files/loan_tape.parquet'
),

-- ============================================================================
-- SECTION 2: DEDUCTIONS CTE
-- ============================================================================

-- CTE to calculate deducted period difference
deductions AS (
    SELECT
        loan_id,
        report_date,
        loan_start_date,
        number_months_deducted,
        -- Calculate months difference (DuckDB DATE_DIFF)
        DATE_DIFF('month', CAST(loan_start_date AS DATE), CAST(report_date AS DATE)) AS months_elapsed,
        -- Deduct remaining with business logic
        CASE 
            WHEN DATE_DIFF('month', CAST(loan_start_date AS DATE), CAST(report_date AS DATE)) >= number_months_deducted 
                THEN 0
            ELSE number_months_deducted - DATE_DIFF('month', CAST(loan_start_date AS DATE), CAST(report_date AS DATE))
        END AS deducted_period_remaining
    FROM 'parquet_files/loan_tape.parquet'
)

-- ============================================================================
-- SECTION 3: MAIN SELECT QUERY
-- ============================================================================

SELECT 
    -- ================================================================
    -- IDENTIFIERS
    -- ================================================================
    r.reporting_date AS reporting_date,
    r.account_id AS account_id,
    r.ifrs9_portfolio_type AS ifrs9_portfolio_type,

    -- ================================================================
    -- BALANCE CALCULATIONS
    -- ================================================================
    -- Updated Contractual Balance including first charge
    r.current_contractual_balance + COALESCE(ls.existing_first_charge, 0) AS current_contractual_balance,

    r.balloon_payment AS balloon_payment,
    
    -- ================================================================
    -- INTEREST RATES
    -- ================================================================
    r.contractual_interest_rate_inside_any_fixed_rate_period / 100 AS contractual_interest_rate_inside_any_fixed_rate_period,
    r.contractual_interest_rate_outside_any_fixed_rate_period / 100 AS contractual_interest_rate_outside_any_fixed_rate_period,
    r.fixed_rate_period_end_date AS fixed_rate_period_end_date,
    
    -- ================================================================
    -- REPAYMENT & DATES
    -- ================================================================
    r.contractual_repayment_amount_outside_any_capital_repayment_holiday AS contractual_repayment_amount_outside_any_capital_repayment_holiday,
    r.capital_repayment_holiday_end_date AS capital_repayment_holiday_end_date,
    r.start_date AS start_date,
    r.loan_maturity_date AS loan_maturity_date,
    
    -- ================================================================
    -- ARREARS & FLAGS
    -- ================================================================
    r.days_past_due_dpd AS days_past_due,
    'FALSE' AS watchlist_flag,
    r.forbearance_flag AS forbearance_flag,

    -- ================================================================
    -- SECURITY TYPE MAPPINGS
    -- ================================================================
    CASE 
        WHEN r.security_type = 'Garage Vehicle Showrooms' THEN 'Garage / Vehicle showrooms'
        WHEN r.security_type = 'Convenience Retail Store' THEN 'Retail Units (Lock Up)'
        WHEN r.security_type = 'Small HMO upto 6' THEN 'Dwelling House'
        WHEN r.security_type = 'Large HMO over 6' THEN 'Dwelling House'
        WHEN r.security_type = 'Guest Houses' THEN 'Guest Houses B&B'
        WHEN r.security_type = 'Semi Commercial Property less than 50%' THEN 'Semi Commercial Investment Property - 20% to 50% residential floorspace'
        WHEN r.security_type = 'Semi Commercial Property 50% to 99%' THEN 'Semi Commercial Investment Property - 20% to 50% residential floorspace'
        WHEN r.security_type = 'Hospitals And Nursing Homes' THEN 'Commercial Property - Hospitals, Nursing homes'
        WHEN r.security_type = 'Semi Commercial Investment Property - 20% to 50% residential floorspace' THEN 'Semi Commercial Property – less than 50%'
        WHEN r.security_type = 'Semi Commercial Investment Property - 51% to 80% residential floorspace' THEN 'Semi Commercial Property – 50% to 99%'
        ELSE r.security_type
    END AS security_type,

    -- ================================================================
    -- SECURITY VALUE
    -- ================================================================
    -- Conditional Security Value override
    CASE 
        WHEN r.account_id = 'ZH3966' THEN 1500000 
        ELSE r.security_value 
    END AS security_value,

    -- ================================================================
    -- ASSET INFORMATION
    -- ================================================================
    r.age_of_asset_at_time_of_finance AS "age_of_asset_(at_time_of_finance)",
    r.brand AS brand,
    r.high_emission_vehicle_low_emission_vehicle AS vehicle_emission,
    r.government_guarantee_type AS government_schema_type,
    r.government_guarantee_percentage AS government_guarantee_percentage,
    r.ifrs9_product_type AS ifrs9_product_type,

    -- ================================================================
    -- RISK GRADES
    -- ================================================================
    -- Align Risk Grades: current_rg updated to match origination_rg if different
    CASE 
        WHEN r.origination_rg IS NOT NULL AND r.origination_rg != r.current_rg 
            THEN r.origination_rg
        ELSE COALESCE(r.current_rg, 10)
    END AS current_rg,

    r.origination_rg AS origination_rg,
    r.origination_after_1m_rg AS origination_after_1m_rg,
    r.sicr_current_rg AS sicr_current_rg,
    
    -- ================================================================
    -- PORTFOLIO & LEGAL INFORMATION
    -- ================================================================
    r.portfolio_type_fs AS portfolio_type_fs,
    r.borrower_legal_entity AS borrower_legal_entity,
    r.portfolio_type_1 AS portfolio_type_1,
    r.customer_legal_type AS company_legal_type,
    r.company_reg_number AS company_reg_no,
    
    -- ================================================================
    -- DEDUCTIONS DATA
    -- ================================================================
    d.deducted_period_remaining AS deducted_period_remaining,
    d.months_elapsed AS months_elapsed,

    -- ================================================================
    -- LOAN TAPE DATA
    -- ================================================================
    ls.report_date AS report_date,
    ls.loan_start_date AS loan_start_date,
    ls.number_months_deducted AS number_months_deducted,
    ls.original_term AS original_term,
    ls.current_gross_loan AS current_gross_loan,
    ls.current_maximum_rolled_interest AS current_maximum_rolled_interest,
    ls.total_interest_rolled AS total_interest_rolled,
    ls.deal_type AS deal_type,
    
    -- ================================================================
    -- CREDIT SCORES
    -- ================================================================
    ls.original_credit_score AS commercial_delphi_score,
    ls.original_credit_score AS commercial_delphi_score_orig,
    NULL AS delphi_cashflow_score,
    NULL AS delphi_cashflow_score_orig,
    NULL AS fc_delphi_band,
    NULL AS fc_delphi_band_orig

-- ============================================================================
-- JOINS
-- ============================================================================
FROM 'parquet_files/rmc_tuscan.parquet' r

LEFT JOIN latest_scores ls 
    ON r.account_id = ls.loan_id AND ls.rn = 1
    
LEFT JOIN deductions d
    ON r.account_id = d.loan_id AND r.reporting_date = d.report_date

-- ============================================================================
-- FILTERS
-- ============================================================================
WHERE r.reporting_date = (SELECT MAX(reporting_date) FROM 'parquet_files/rmc_tuscan.parquet')
  AND r.account_id != 'CA001880'

ORDER BY r.account_id ASC;
