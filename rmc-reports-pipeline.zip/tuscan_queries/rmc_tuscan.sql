-- ============================================================================
-- Report Name: RMC_TUSCAN - PARQUET VERSION
-- ============================================================================
-- Original Author: Divyanshi Singhal
-- Adapted for: DuckDB + Parquet files
-- Description: TUSCAN - Bridging Finance Analytics
-- 
-- Data Sources:
-- - parquet_files/loan_tape.parquet
-- - parquet_files/security_tape.parquet
-- - parquet_files/risk_info.parquet
-- - parquet_files/sic_code.parquet
-- ============================================================================

WITH
-- ============================================================================
-- SECTION 1: SECURITY DATA PROCESSING
-- ============================================================================

-- Get latest security records for each loan
CTE_latest_month_securities AS (
    SELECT * FROM (
        SELECT *,
            ROW_NUMBER() OVER (PARTITION BY loan_id, security_id ORDER BY report_date DESC) AS rnk
        FROM 'parquet_files/security_tape.parquet'
    ) base
    WHERE rnk = 1
),

-- Filter to held securities only
CTE_all_held_securities AS (
    SELECT *
    FROM CTE_latest_month_securities
    WHERE security_status = 'Held'
),

-- Aggregate held securities by loan
CTE_all_held_securities_agg AS (
    SELECT
        loan_id,
        SUM(COALESCE(latest_vpv, latest_mv1)) AS security_value,
        COUNT(security_id) AS tangible_collateral_count
    FROM CTE_all_held_securities
    GROUP BY loan_id
),

-- Get highest value security data (region, postcode, valuation date)
CTE_all_held_highest_value_data AS (
    SELECT DISTINCT
        FIRST_VALUE(loan_id) OVER (PARTITION BY loan_id ORDER BY COALESCE(latest_vpv, latest_mv1) DESC) AS loan_id,
        FIRST_VALUE(region) OVER (PARTITION BY loan_id ORDER BY COALESCE(latest_vpv, latest_mv1) DESC) AS region,
        FIRST_VALUE(postcode) OVER (PARTITION BY loan_id ORDER BY COALESCE(latest_vpv, latest_mv1) DESC) AS postcode,
        FIRST_VALUE(original_valuation_date) OVER (PARTITION BY loan_id ORDER BY COALESCE(latest_vpv, latest_mv1) DESC) AS original_valuation_date
    FROM CTE_all_held_securities
),

-- Calculate original valuation sum
CTE_original_valuation AS (
    SELECT 
        loan_id,
        SUM(COALESCE(original_vpv, original_mv1)) AS original_valuation
    FROM CTE_latest_month_securities
    GROUP BY loan_id
),

-- Get highest security type and latest valuation date
CTE_highest_security_data AS (
    SELECT DISTINCT
        FIRST_VALUE(loan_id) OVER (PARTITION BY loan_id ORDER BY COALESCE(latest_vpv, latest_mv1) DESC) AS loan_id,
        FIRST_VALUE(security_type) OVER (PARTITION BY loan_id ORDER BY COALESCE(latest_vpv, latest_mv1) DESC) AS security_type,
        FIRST_VALUE(latest_valuation_date) OVER (PARTITION BY loan_id ORDER BY COALESCE(latest_vpv, latest_mv1) DESC) AS latest_valuation_date
    FROM CTE_latest_month_securities
),

-- Consolidate all security data
CTE_security_data_agg AS (
    SELECT DISTINCT 
        vw_tuscan_securities.loan_id,
        CTE_all_held_securities_agg.security_value,
        CTE_all_held_securities_agg.tangible_collateral_count,
        CTE_all_held_highest_value_data.original_valuation_date,
        CTE_all_held_highest_value_data.postcode,
        CTE_all_held_highest_value_data.region,
        CTE_original_valuation.original_valuation,
        CTE_highest_security_data.latest_valuation_date,
        CTE_highest_security_data.security_type
    FROM CTE_latest_month_securities vw_tuscan_securities
    LEFT JOIN CTE_all_held_securities_agg 
        ON vw_tuscan_securities.loan_id = CTE_all_held_securities_agg.loan_id
    LEFT JOIN CTE_all_held_highest_value_data 
        ON vw_tuscan_securities.loan_id = CTE_all_held_highest_value_data.loan_id
    LEFT JOIN CTE_original_valuation 
        ON vw_tuscan_securities.loan_id = CTE_original_valuation.loan_id
    LEFT JOIN CTE_highest_security_data 
        ON vw_tuscan_securities.loan_id = CTE_highest_security_data.loan_id
),

-- ============================================================================
-- SECTION 2: LOAN DATA PROCESSING
-- ============================================================================

-- Get latest loan records
vw_tuscan_loans AS (
    SELECT * FROM (
        SELECT *,
            ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY report_date DESC) AS rnk
        FROM 'parquet_files/loan_tape.parquet'
    ) base 
    WHERE rnk = 1
      AND loan_status != 'Redeemed'
)

-- ============================================================================
-- SECTION 3: MAIN REPORT QUERY
-- ============================================================================

SELECT
    -- ========================================================================
    -- IDENTIFIERS & ADMINISTRATIVE
    -- ========================================================================
    CURRENT_DATE AS reporting_date,
    vw_tuscan_loans.borrower_id AS ledger_borrower_id,
    vw_tuscan_loans.loan_id AS account_id,
    NULL AS fms_load_id,
    
    -- ========================================================================
    -- LOAN AMOUNTS & BALANCE
    -- ========================================================================
    CAST(
        current_net_principal_outstanding + COALESCE(undrawn_committed_amount, 0) 
        AS DECIMAL(21,2)
    ) AS current_contractual_balance,
    0 AS balloon_payment,
    NULL AS contractual_repayment_amount_outside_any_capital_repayment_holiday,
    CAST(loan_start_date AS DATE) AS capital_repayment_holiday_end_date,
    
    -- ========================================================================
    -- LOAN TYPE & STRUCTURE
    -- ========================================================================
    CASE
        WHEN amort_type = 'Amort' THEN 'Amort'
        ELSE 'I/O'
    END AS deal_type_io_amortising,
    
    CAST(loan_start_date AS DATE) AS start_date,
    strftime(CAST(loan_start_date AS DATE), '%m-%Y') AS new_origination_date,
    strftime(CAST(loan_start_date AS DATE), '%m') AS vintage_month,
    EXTRACT(QUARTER FROM CAST(loan_start_date AS DATE)) AS vintage_quarter,
    strftime(CAST(loan_start_date AS DATE), '%Y') AS vintage_year,
    CONCAT(
        EXTRACT(YEAR FROM CAST(loan_start_date AS DATE)), 
        ' Q', 
        EXTRACT(QUARTER FROM CAST(loan_start_date AS DATE))
    ) AS vintage_slide,
    
    -- ========================================================================
    -- MATURITY INFORMATION
    -- ========================================================================
    strftime(CAST(current_maturity_date AS DATE), '%Y') AS maturity_year,
    CAST(current_maturity_date AS DATE) AS loan_maturity_date,
    CASE
        WHEN CAST(current_maturity_date AS DATE) < CURRENT_DATE + INTERVAL '1 year' 
        THEN 'Below 1 Year'
        ELSE 'Above 1 Year'
    END AS maturity_profile,
    
    -- ========================================================================
    -- BORROWER INFORMATION
    -- ========================================================================
    CASE
        WHEN introducing_broker IS NULL THEN 'Tuscan Direct'
        ELSE introducing_broker
    END AS introducer_firm_name,
    
    borrower_name,
    company_reg_number,
    borrower_type AS borrower_legal_entity,
    borrower_postcode AS borrower_registered_address_postcode,
    borrower_region AS borrower_registered_address_region,
    
    -- Borrower country mapping
    CASE borrower_region
        WHEN 'Scotland' THEN 'Scotland'
        WHEN 'Greater London' THEN 'England'
        WHEN 'North West' THEN 'England'
        WHEN 'South West' THEN 'England'
        WHEN 'West Midlands' THEN 'England'
        WHEN 'East Midlands' THEN 'England'
        WHEN 'South East' THEN 'England'
        WHEN 'Yorkshire and the Humber' THEN 'England'
        WHEN 'North East' THEN 'England'
        WHEN 'East of England' THEN 'England'
        WHEN 'Wales' THEN 'Wales'
        WHEN 'Northern Ireland' THEN 'Northern Ireland'
        WHEN 'Overseas' THEN 'Overseas'
        ELSE borrower_region
    END AS borrower_registered_address_country,
    
    -- Customer legal type
    CASE
        WHEN borrower_type IN (
            'Club', 'Charity', 'Society', 'Joint', 'Other', 
            'Overseas Company', 'Partnership', 'Unlimited Company', 'Trust'
        ) THEN 'Company'
        WHEN borrower_type IN (
            'Ltd Liability Partnership', 'Public Limited Company', 'Limited Company'
        ) THEN 'Limited Company'
        WHEN borrower_type = 'Sole Trader' THEN 'Individual'
        ELSE borrower_type
    END AS customer_legal_type,
    
    -- ========================================================================
    -- BUSINESS CLASSIFICATION
    -- ========================================================================
    'Data to be available in the future, not available currently' AS customer_nace_code,
    borrower_sme_flag AS sme_flag,
    
    -- Extract first SIC code if multiple exist (cast to string first)
    CASE
        WHEN LENGTH(CAST(borrower_sic_code AS VARCHAR)) < 6 THEN CAST(borrower_sic_code AS VARCHAR)
        ELSE SUBSTRING(CAST(borrower_sic_code AS VARCHAR), 1, STRPOS(CAST(borrower_sic_code AS VARCHAR), ';') - 1)
    END AS sic_code,
    
    SIC_Code.profession_description,
    SIC_Code.business_segment,
    SIC_Code.business_segment AS sector,
    
    -- ========================================================================
    -- RISK INDICATORS & STATUS
    -- ========================================================================
    dpd AS days_past_due_dpd,
    
    CASE
        WHEN dpd = 0 THEN '1. Up to date'
        WHEN dpd BETWEEN 1 AND 29 THEN '2. 1DPD - 29DPD'
        WHEN dpd BETWEEN 30 AND 89 THEN '3. 30DPD - 89DPD'
        WHEN dpd >= 90 THEN '4. 90+ DPD'
        ELSE 'Invalid DPD value'
    END AS dpd_status,
    
    watchlist_flag,
    NULL AS watchlist,
    
    CASE
        WHEN forbearance_flag = 'True' 
            OR (CURRENT_DATE > CAST(current_maturity_date AS DATE) AND dpd >= 1)
        THEN 'True'
        ELSE 'False'
    END AS forbearance_flag,
    
    -- ========================================================================
    -- SECURITY TYPE CLASSIFICATION
    -- ========================================================================
    CASE
        WHEN CTE_security_data_agg.security_type = 'Retail_Units_Lock_Up' THEN 'Retail Units (Lock Up)'
        WHEN CTE_security_data_agg.security_type = 'HMO_>=5_Beds' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Semi_detached_House' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Mixed_Use_Multi_Let' THEN 'Mixed Use / Multi-Let (exc Residential and Retail)'
        WHEN CTE_security_data_agg.security_type = 'Detached_House' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Masionette' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Terraced_House' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Flat' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Bungalow' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'End_Of_Terrace_House' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'HMO_<5_Beds' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Children_Day_Nurseries' THEN 'Childrens Day Nurseries'
        WHEN CTE_security_data_agg.security_type = 'Commercial_Units_With_Residential_Uppers' THEN 'Retail Units with Residential Uppers'
        ELSE REPLACE(CTE_security_data_agg.security_type, '_', ' ')
    END AS security_type,
    
    NULL AS sub_security_type,
    NULL AS age_of_asset_at_time_of_finance,
    NULL AS brand,
    NULL AS high_emission_vehicle_low_emission_vehicle,
    NULL AS restructure_flag,
    
    -- ========================================================================
    -- LOAN FINANCIALS
    -- ========================================================================
    original_net_principal_outstanding AS original_balance,
    
    CASE
        WHEN rate_type = 'Fixed' THEN floating_margin_annual
        ELSE NULL
    END AS current_interest_rate_margin,
    
    gross_rate_annual AS current_gross_interest_rate,
    NULL AS overdraft_interest_rate,
    
    CASE
        WHEN rate_type = 'Fixed' THEN CAST(current_maturity_date AS DATE)
        ELSE CAST(loan_start_date AS DATE)
    END AS fixed_rate_period_end_date,
    
    gross_rate_annual AS contractual_interest_rate_inside_any_fixed_rate_period,
    gross_rate_annual AS contractual_interest_rate_outside_any_fixed_rate_period,
    
    CASE
        WHEN rate_type = 'Fixed' THEN 'True'
        ELSE 'False'
    END AS fixed_rate_flag,
    
    NULL AS is_rls,
    NULL AS government_guarantee_type,
    NULL AS government_guarantee_percentage,
    NULL AS hmo_or_mufb,
    
    -- ========================================================================
    -- PROPERTY LOCATION
    -- ========================================================================
    CTE_security_data_agg.postcode,
    CTE_security_data_agg.region,
    
    CASE CTE_security_data_agg.region
        WHEN 'Scotland' THEN 'Scotland'
        WHEN 'Greater London' THEN 'England'
        WHEN 'North West' THEN 'England'
        WHEN 'South West' THEN 'England'
        WHEN 'West Midlands' THEN 'England'
        WHEN 'East Midlands' THEN 'England'
        WHEN 'South East' THEN 'England'
        WHEN 'Yorkshire and the Humber' THEN 'England'
        WHEN 'North East' THEN 'England'
        WHEN 'East of England' THEN 'England'
        WHEN 'Wales' THEN 'Wales'
        WHEN 'Northern Ireland' THEN 'Northern Ireland'
        WHEN 'Overseas' THEN 'Overseas'
        ELSE CTE_security_data_agg.region
    END AS country,
    
    -- ========================================================================
    -- LTV METRICS
    -- ========================================================================
    original_net_principal_ltv AS origination_ltv,
    current_net_principal_ltv AS current_ltv,
    original_net_principal_ltv * current_gross_loan * 1.0 AS weighted_ltv,
    
    CAST(CTE_security_data_agg.original_valuation_date AS DATE) AS original_valuation_date,
    CAST(CTE_security_data_agg.latest_valuation_date AS DATE) AS current_valuation_date,
    CAST(NULL AS DATE) AS loan_application_approval_rejection_date,
    
    -- ========================================================================
    -- PORTFOLIO CLASSIFICATION
    -- ========================================================================
    'CM' AS ifrs9_portfolio_type,
    'Tuscan' AS portfolio_type_1,
    CONCAT('Tuscan', ' - ', loan_type) AS portfolio_type_2,
    CONCAT('Tuscan', ' - ', loan_type, ' - ', sub_loan_type) AS portfolio_type_3,
    'Bridging Finance' AS portfolio_type_fs,
    loan_type AS product_type,
    'Bridging Loan' AS sub_product,
    
    -- ========================================================================
    -- ASSET TYPE CLASSIFICATION (asset_type1)
    -- ========================================================================
    CASE
        WHEN CTE_security_data_agg.security_type = 'Children_Day_Nurseries' THEN 'Childrens Day Nurseries'
        WHEN CTE_security_data_agg.security_type = 'Convenience_Retail_Store' THEN 'Convenience stores'
        WHEN CTE_security_data_agg.security_type = 'Elderly_Care_Homes' THEN 'Elderly Care Homes'
        WHEN CTE_security_data_agg.security_type = 'Factories' THEN 'Factories'
        WHEN CTE_security_data_agg.security_type = 'Food_Outlets' THEN 'Food Outlets'
        WHEN CTE_security_data_agg.security_type = 'Garage_Vehicle_Showrooms' THEN 'Garage / Vehicle showrooms'
        WHEN CTE_security_data_agg.security_type = 'Guest_Houses' THEN 'Guest Houses B&B'
        WHEN CTE_security_data_agg.security_type = 'Holiday_Lets' THEN 'Holiday Lets'
        WHEN CTE_security_data_agg.security_type = 'Hospitals_And_Nursing_Homes' THEN 'Hospital and Nursing Homes'
        WHEN CTE_security_data_agg.security_type = 'Hotels' THEN 'Hotels'
        WHEN CTE_security_data_agg.security_type = 'Industrial_Units' THEN 'Industrial Units'
        WHEN CTE_security_data_agg.security_type = 'Leisure' THEN 'Leisure'
        WHEN CTE_security_data_agg.security_type = 'Mixed_Use_Multi_Let' THEN 'Mixed Use / Multi-Let (exc Residential and Retail)'
        WHEN CTE_security_data_agg.security_type = 'Offices' THEN 'Offices'
        WHEN CTE_security_data_agg.security_type = 'Professional_Practices' THEN 'Professional Practices'
        WHEN CTE_security_data_agg.security_type = 'Public_Houses' THEN 'Public Houses'
        WHEN CTE_security_data_agg.security_type = 'Retail_Units_Lock_Up' THEN 'Retail Units (Lock Up)'
        WHEN CTE_security_data_agg.security_type = 'Student_Accommodation' THEN 'Student Accomodation'
        WHEN CTE_security_data_agg.security_type = 'Training_Building' THEN 'Training Building'
        WHEN CTE_security_data_agg.security_type = 'Warehouses' THEN 'Warehouses'
        WHEN CTE_security_data_agg.security_type = 'Commercial_Units_With_Residential_Uppers' THEN 'Commercial Units With Residential Uppers'
        WHEN CTE_security_data_agg.security_type = 'Retail_Units_With_Commercial_Uppers' THEN 'Retail Units with Commercial Uppers'
        WHEN CTE_security_data_agg.security_type = 'Retail_Units_With_Residential_Uppers' THEN 'Retail Units with Residential Uppers'
        WHEN CTE_security_data_agg.security_type = 'Bungalow' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Detached_House' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'End_Of_Terrace_House' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Flat' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'HMO_<5_Beds' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'HMO_>=5_Beds' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Masionette' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Semi_detached_House' THEN 'Dwelling House'
        WHEN CTE_security_data_agg.security_type = 'Terraced_House' THEN 'Dwelling House'
        ELSE CTE_security_data_agg.security_type
    END AS asset_type1,
    
    -- ========================================================================
    -- ASSET TYPE CLASSIFICATION (asset_type2)
    -- ========================================================================
    CASE
        WHEN CTE_security_data_agg.security_type = 'Children_Day_Nurseries' THEN 'Specialist Use'
        WHEN CTE_security_data_agg.security_type = 'Convenience_Retail_Store' THEN 'Other'
        WHEN CTE_security_data_agg.security_type = 'Elderly_Care_Homes' THEN 'Specialist Use'
        WHEN CTE_security_data_agg.security_type = 'Factories' THEN 'Industrial Units'
        WHEN CTE_security_data_agg.security_type = 'Food_Outlets' THEN 'Hospitality'
        WHEN CTE_security_data_agg.security_type = 'Garage_Vehicle_Showrooms' THEN 'Retail'
        WHEN CTE_security_data_agg.security_type = 'Guest_Houses' THEN 'Hospitality'
        WHEN CTE_security_data_agg.security_type = 'Holiday_Lets' THEN 'Hospitality'
        WHEN CTE_security_data_agg.security_type = 'Hospitals_And_Nursing_Homes' THEN 'Specialist Use'
        WHEN CTE_security_data_agg.security_type = 'Hotels' THEN 'Hospitality'
        WHEN CTE_security_data_agg.security_type = 'Industrial_Units' THEN 'Industrial Units'
        WHEN CTE_security_data_agg.security_type = 'Leisure' THEN 'Hospitality'
        WHEN CTE_security_data_agg.security_type = 'Mixed_Use_Multi_Let' THEN 'Other'
        WHEN CTE_security_data_agg.security_type = 'Offices' THEN 'Offices'
        WHEN CTE_security_data_agg.security_type = 'Professional_Practices' THEN 'Specialist Use'
        WHEN CTE_security_data_agg.security_type = 'Public_Houses' THEN 'Hospitality'
        WHEN CTE_security_data_agg.security_type = 'Retail_Units_Lock_Up' THEN 'Retail'
        WHEN CTE_security_data_agg.security_type = 'Student_Accommodation' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'Training_Building' THEN 'Other'
        WHEN CTE_security_data_agg.security_type = 'Warehouses' THEN 'Industrial Units'
        WHEN CTE_security_data_agg.security_type = 'Commercial_Units_With_Residential_Uppers' THEN 'Other'
        WHEN CTE_security_data_agg.security_type = 'Retail_Units_With_Commercial_Uppers' THEN 'Retail'
        WHEN CTE_security_data_agg.security_type = 'Retail_Units_With_Residential_Uppers' THEN 'Retail'
        WHEN CTE_security_data_agg.security_type = 'Bungalow' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'Detached_House' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'End_Of_Terrace_House' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'Flat' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'HMO_<5_Beds' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'HMO_>=5_Beds' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'Masionette' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'Semi_detached_House' THEN 'Residential'
        WHEN CTE_security_data_agg.security_type = 'Terraced_House' THEN 'Residential'
        ELSE CTE_security_data_agg.security_type
    END AS asset_type2,
    
    -- ========================================================================
    -- ADDITIONAL LOAN DETAILS
    -- ========================================================================
    'Non-CI' AS ifrs9_product_type,
    current_term AS loan_term_months,
    NULL AS pay_as_you_grow_option,
    principal_arrears_balance + interest_arrears_balance AS arrears_balance,
    NULL AS total_vat_deferred,
    NULL AS number_of_missed_payments_inferred_dpd,
    NULL AS guarantor_count,
    insolvency_flag,
    NULL AS arrears_stage,
    borrower_type AS legal_status,
    NULL AS migration_source,
    NULL AS migration_phase,
    connection_id,
    number_months_deducted AS deducted_period_total,
    
    DATE_DIFF('month', 
        LAST_DAY(CAST(loan_start_date AS DATE)), 
        LAST_DAY(CURRENT_DATE)
    ) AS deducted_period_remaining,
    
    CASE
        WHEN CTE_security_data_agg.security_type = 'EPC' THEN 'EPC'
        ELSE NULL
    END AS epc_rating,
    
    'Y' AS property_backed_yn,
    current_gross_loan AS current_gross_balance,
    
    CASE
        WHEN borrower_type = 'Sole Trader' THEN 'NoCRE'
        ELSE 'CRE'
    END AS cre_flag,
    
    -- ========================================================================
    -- VALUATION & COLLATERAL
    -- ========================================================================
    CTE_security_data_agg.original_valuation AS valuation_amount,
    CTE_security_data_agg.tangible_collateral_count,
    CTE_security_data_agg.security_value,
    
    -- ========================================================================
    -- RISK GRADES
    -- ========================================================================
    riskgrades.current_rg,
    riskgrades.origination_rg,
    riskgrades.origination_rg_after_1m AS origination_after_1m_rg,
    riskgrades.sicr_current_rg,
    NULL AS origination_rg_v1,
    NULL AS current_rg_v1,
    
    -- ========================================================================
    -- STATUS & TYPE
    -- ========================================================================
    loan_status AS account_status,
    rate_type AS interest_rate_type,
    sub_loan_type

-- ============================================================================
-- JOINS
-- ============================================================================
FROM vw_tuscan_loans

-- Join SIC Code lookup
LEFT JOIN (
    SELECT * FROM 'parquet_files/sic_code.parquet'
    WHERE LATEST_INDICATOR = 1
) SIC_Code 
ON (
    CAST(
        CASE
            WHEN LENGTH(CAST(vw_tuscan_loans.borrower_sic_code AS VARCHAR)) < 6 
            THEN CAST(vw_tuscan_loans.borrower_sic_code AS VARCHAR)
            ELSE SUBSTRING(CAST(vw_tuscan_loans.borrower_sic_code AS VARCHAR), 1, STRPOS(CAST(vw_tuscan_loans.borrower_sic_code AS VARCHAR), ';') - 1)
        END AS VARCHAR
    )
) = CAST(SIC_Code.sic_code AS VARCHAR)

-- Join security data
LEFT JOIN CTE_security_data_agg 
ON vw_tuscan_loans.loan_id = CTE_security_data_agg.loan_id

-- Join risk grades
LEFT JOIN (
    SELECT * FROM 'parquet_files/risk_info.parquet'
    WHERE source = 'TUSCAN'
) riskgrades
ON riskgrades.contract_id = vw_tuscan_loans.loan_id

ORDER BY current_gross_loan DESC;

