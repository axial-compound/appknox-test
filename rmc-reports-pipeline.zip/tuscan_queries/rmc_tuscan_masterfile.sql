-- ============================================================================
-- Report Name: RMC_TUSCAN_MASTERFILE - PARQUET VERSION
-- ============================================================================
-- Original Author: Mithunan Sathiyandra
-- Adapted for: DuckDB + Parquet files
-- Creation date: 02/10/2024
-- Description: RMC Input dataset format for Tuscan
-- 
-- Data Sources:
-- - parquet_files/loan_tape.parquet
-- - parquet_files/rmc_tuscan.parquet
-- ============================================================================

-- Note: DuckDB doesn't support session variables like SQL Server's DECLARE/SET
-- If you need to parameterize transaction_max_date, pass it via your application
-- Default behavior: uses last day of previous month

WITH 
-- ============================================================================
-- SECTION 1: CREDIT SCORE PROCESSING
-- ============================================================================

-- CTE to select the latest credit score per loan_id
latest_scores AS (
    SELECT 
        loan_id,
        original_credit_score,
        ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY report_date DESC) AS rn
    FROM 'parquet_files/loan_tape.parquet'
),

-- ============================================================================
-- SECTION 2: MAIN REPORT QUERY
-- ============================================================================

main_data AS (
    SELECT 
        -- ================================================================
        -- IDENTIFIERS & METADATA
        -- ================================================================
        'Tuscan RMC' AS report_name,
        
        r.reporting_date AS reporting_date,
        
        -- Format extract_date as DD-MM-YYYY (DuckDB style)
        strftime(CURRENT_DATE, '%d-%m-%Y') AS extract_date,
        
        r.ledger_borrower_id AS ledger_borrower_id,
        
        r.account_id AS account_id,
        
        NULL AS fms_loan_id,
        
        -- ================================================================
        -- BALANCE & AMOUNTS
        -- ================================================================
        r.current_contractual_balance AS current_contractual_balance,
        
        -- ================================================================
        -- DATES
        -- ================================================================
        r.start_date AS start_date,
        
        r.new_origination_date AS new_origination_date,
        
        r.vintage_month AS vintage_month,
        
        r.vintage_quarter AS vintage_quarter,
        
        r.vintage_year AS vintage_year,
        
        r.vintage_slide AS vintage_slide,
        
        r.maturity_year AS maturity_year,
        
        r.loan_maturity_date AS loan_maturity_date,
        
        r.maturity_profile AS maturity_profile,
        
        r.loan_application_approval_rejection_date AS loan_application_approval_rejection_date,
        
        -- ================================================================
        -- BORROWER INFORMATION
        -- ================================================================
        r.introducer_firm_name AS introducer_firm_name,
        
        r.borrower_name AS borrower_name,
        
        r.company_reg_number AS company_reg_no,
        
        r.borrower_legal_entity AS borrower_legal_entity,
        
        r.borrower_registered_address_postcode AS borrower_registered_address_postcode,
        
        CASE 
            WHEN r.borrower_registered_address_region = 'London' THEN 'Greater London'
            WHEN r.borrower_registered_address_region = 'East' THEN 'East of England'
            ELSE r.borrower_registered_address_region
        END AS borrower_registered_address_region,
        
        CASE 
            WHEN r.borrower_registered_address_country = 'London' THEN 'England'
            WHEN r.borrower_registered_address_country = 'East' THEN 'England'
            ELSE r.borrower_registered_address_country
        END AS borrower_registered_address_country,
        
        r.customer_legal_type AS customer_legal_type,
        
        r.customer_nace_code AS customer_nace_code,
        
        -- ================================================================
        -- COLLATERAL LOCATION
        -- ================================================================
        r.postcode AS collateral_postcode,
        
        CASE 
            WHEN r.region = 'London' THEN 'Greater London'
            WHEN r.region = 'East' THEN 'East of England'
            ELSE r.region
        END AS collateral_region,
        
        CASE 
            WHEN r.country = 'London' THEN 'England'
            WHEN r.country = 'East' THEN 'England'
            ELSE r.country
        END AS collateral_country,
        
        -- ================================================================
        -- BUSINESS CLASSIFICATION
        -- ================================================================
        r.sme_flag AS sme_flag,
        
        r.sic_code AS sic_code,
        
        LEFT(CAST(r.sic_code AS VARCHAR), 4) AS sic_code_refined,
        
        r.profession_description AS profession_description,
        
        r.business_segment AS business_segment,
        
        r.sector AS sector,
        
        CASE 
            WHEN r.sector = 'Accommodation And Food Service Activities' THEN 'Accommodation and Food'
            WHEN r.sector = 'Activities Of Households As Employers' THEN 'Activities of Households'
            WHEN r.Sector = 'Administrative And Support Service Activities' THEN 'Administrative and Support'
            WHEN r.sector = 'Financial And Insurance Activities' THEN 'Financial and Insurance'
            WHEN r.sector = 'Human Health And Social Work Activities' THEN 'Human Health and Social Work'
            WHEN r.sector = 'Water Supply; Sewerage, Waste Management And Remediation Activities' THEN 'Water Supply; Sewerage and Waste Management'
            WHEN r.sector = 'Wholesale And Retail Trade; Repair Of Motor Vehicles And Motorcycles' THEN 'Wholesale and Retail Trade'
            WHEN r.sector IN (
                'Activities Of Extraterritorial Organisations And Bodies', 
                'Electricity, Gas, Steam And Air Conditioning Supply', 
                'Mining And Quarrying', 
                'Other Service Activities', 
                'Public Administration And Defence; Compulsory Social Security'
            ) THEN 'Other'
            ELSE r.sector
        END AS sector_fs,
        
        CASE WHEN r.sector = 'human health and social work activities' THEN 'Yes' ELSE 'No' END AS hospitality_flag,
        
        CASE WHEN r.sector = 'human health and social work activities' THEN 'Yes' ELSE 'No' END AS healthcare_flag,
        
        -- ================================================================
        -- INTEREST RATES
        -- ================================================================
        r.current_gross_interest_rate / 100 AS current_gross_interest_rate,
        
        r.current_interest_rate_margin / 100 AS current_interest_rate_margin,
        
        r.overdraft_interest_rate / 100 AS overdraft_interest_rate,
        
        r.fixed_rate_period_end_date AS fixed_rate_period_end_date,
        
        r.contractual_interest_rate_inside_any_fixed_rate_period / 100 AS contractual_interest_rate_inside_any_fixed_rate_period,
        
        r.contractual_interest_rate_outside_any_fixed_rate_period / 100 AS contractual_interest_rate_outside_any_fixed_rate_period,
        
        r.fixed_rate_flag AS fixed_rate_flag,
        
        -- ================================================================
        -- GOVERNMENT & GUARANTEE
        -- ================================================================
        r.is_rls AS is_rls,
        
        r.government_guarantee_type AS government_guarantee_type,
        
        r.government_guarantee_percentage AS government_guarantee_percentage,
        
        -- ================================================================
        -- LTV CALCULATIONS
        -- ================================================================
        r.origination_ltv / 100 AS origination_ltv,
        
        CASE 
            WHEN r.security_value IN (0, NULL) THEN NULL
            ELSE r.current_contractual_balance / r.security_value
        END AS "current_pre-index_ltv",
        
        -- ================================================================
        -- LTV BANDS
        -- ================================================================
        CASE 
            WHEN r.origination_ltv > 1 AND 0 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.55 THEN '1. below 55%'
            WHEN r.origination_ltv > 1 AND 0.55 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.60 THEN '2. 55% to < 60%'
            WHEN r.origination_ltv > 1 AND 0.60 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.65 THEN '3. 60% to <65%'
            WHEN r.origination_ltv > 1 AND 0.65 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.70 THEN '4. 65% to <70%'
            WHEN r.origination_ltv > 1 AND 0.70 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.75 THEN '5. 70% to <75%'
            WHEN r.origination_ltv > 1 AND 0.75 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.80 THEN '6. 75% to < 80%'
            WHEN r.origination_ltv > 1 AND 0.80 <= r.origination_ltv/100 THEN '7. 80% and above'
            WHEN 0 < r.origination_ltv AND r.origination_ltv < 0.55 THEN '1. below 55%'
            WHEN 0.55 <= r.origination_ltv AND r.origination_ltv < 0.60 THEN '2. 55% to < 60%'
            WHEN 0.60 <= r.origination_ltv AND r.origination_ltv < 0.65 THEN '3. 60% to <65%'
            WHEN 0.65 <= r.origination_ltv AND r.origination_ltv < 0.70 THEN '4. 65% to <70%'
            WHEN 0.70 <= r.origination_ltv AND r.origination_ltv < 0.75 THEN '5. 70% to <75%'
            WHEN 0.75 <= r.origination_ltv AND r.origination_ltv < 0.80 THEN '6. 75% to < 80%'
            WHEN 0.80 <= r.origination_ltv THEN '7. 80% and above'
            ELSE NULL
        END AS origination_ltv_band_pre_index,
        
        CASE 
            WHEN r.security_value IN (0, NULL) THEN NULL
            WHEN 0 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.55 THEN '1. below 55%'
            WHEN 0.55 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.60 THEN '2. 55% to < 60%'
            WHEN 0.60 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.65 THEN '3. 60% to <65%'
            WHEN 0.65 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.70 THEN '4. 65% to <70%'
            WHEN 0.70 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.75 THEN '5. 70% to <75%'
            WHEN 0.75 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.80 THEN '6. 75% to < 80%'
            WHEN 0.80 <= r.current_contractual_balance/r.security_value THEN '7. 80% and above'
            ELSE NULL
        END AS current_ltv_band_pre_index,                                                                        
        
        CASE 
            WHEN r.origination_ltv > 1 AND 0 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.55 THEN '1. ≤55%'
            WHEN r.origination_ltv > 1 AND 0.55 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.60 THEN '2. >55%, ≤60%'
            WHEN r.origination_ltv > 1 AND 0.60 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.65 THEN '3. >60%, ≤65%'
            WHEN r.origination_ltv > 1 AND 0.65 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.70 THEN '4. >65%, ≤70%'
            WHEN r.origination_ltv > 1 AND 0.70 <= r.origination_ltv/100 AND r.origination_ltv/100 < 0.75 THEN '5. >70%, ≤75%'
            WHEN r.origination_ltv > 1 AND 0.75 <= r.origination_ltv/100 AND r.origination_ltv/100 < 1 THEN '6. >75%, ≤100%'
            WHEN r.origination_ltv > 1 AND 1 <= r.origination_ltv/100 THEN '7. > 100%'
            WHEN 0 < r.origination_ltv AND r.origination_ltv < 0.55 THEN '1. ≤55%'
            WHEN 0.55 <= r.origination_ltv AND r.origination_ltv < 0.60 THEN '2. >55%, ≤60%'
            WHEN 0.60 <= r.origination_ltv AND r.origination_ltv < 0.65 THEN '3. >60%, ≤65%'
            WHEN 0.65 <= r.origination_ltv AND r.origination_ltv < 0.70 THEN '4. >65%, ≤70%'
            WHEN 0.70 <= r.origination_ltv AND r.origination_ltv < 0.75 THEN '5. >70%, ≤75%'
            WHEN 0.75 <= r.origination_ltv AND r.origination_ltv < 1 THEN '6. >75%, ≤100%'
            WHEN 1 <= r.origination_ltv THEN '7. > 100%'
            ELSE NULL
        END AS origination_ltv_band_fs_pre_index,
        
        CASE 
            WHEN r.security_value IN (0, NULL) THEN NULL
            WHEN 0 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.55 THEN '1. ≤55%'
            WHEN 0.55 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.60 THEN '2. >55%, ≤60%'
            WHEN 0.60 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.65 THEN '3. >60%, ≤65%'
            WHEN 0.65 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.70 THEN '4. >65%, ≤70%'
            WHEN 0.70 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 0.75 THEN '5. >70%, ≤75%'
            WHEN 0.75 <= r.current_contractual_balance/r.security_value AND r.current_contractual_balance/r.security_value < 1 THEN '6. >75%, ≤100%'
            WHEN 1 <= r.current_contractual_balance/r.security_value THEN '7. > 100%'
            ELSE NULL
        END AS current_ltv_band_fs_pre_index,
        
        r.weighted_ltv AS weighted_ltv,
        
        CASE 
            WHEN r.security_value IN (0, NULL) THEN NULL
            ELSE (r.current_contractual_balance/r.security_value) * r.current_contractual_balance
        END AS weighted_ltv_fs_pre_index,
        
        -- ================================================================
        -- PORTFOLIO & PRODUCT INFORMATION
        -- ================================================================
        r.capital_repayment_holiday_end_date AS capital_repayment_holiday_end_date,
        
        r.ifrs9_portfolio_type AS ifrs9_portfolio_type,
        
        r.portfolio_type_1 AS portfolio_type_1,
        r.portfolio_type_2 AS portfolio_type_2,
        r.portfolio_type_3 AS portfolio_type_3,
        
        r.portfolio_type_fs AS portfolio_type_fs,
        
        r.product_type AS product_type,
        r.sub_product AS sub_product,
        
        -- ================================================================
        -- ASSET TYPE CLASSIFICATION
        -- ================================================================
        CASE 
            WHEN r.asset_type1 = 'Commercial Units With Residential Uppers' THEN 'Retail Units with Residential Uppers' 
            WHEN r.asset_type1 = 'Semi Commercial Investment Property - 20% to 50% residential floorspace' THEN 'Semi Commercial Property – less than 50%'
            WHEN r.asset_type1 = 'Semi Commercial Investment Property - 51% to 80% residential floorspace' THEN 'Semi Commercial Property – 50% to 99%'
            ELSE r.asset_type1
        END AS asset_type_1,
        
        CASE
            WHEN r.asset_type2 = 'Commercial Units With Residential Uppers' THEN 'Retail'
            WHEN r.asset_type2 = 'Semi Commercial Investment Property - 20% to 50% residential floorspace' THEN 'Semi Commercial Property – less than 50%'
            WHEN r.asset_type2 = 'Semi Commercial Investment Property - 51% to 80% residential floorspace' THEN 'Semi Commercial Property – 50% to 99%'
            ELSE r.asset_type2
        END AS asset_type_2,
        
        r.loan_term_months AS loan_term_months,
        
        r.deal_type_io_amortising AS deal_type_io_amortising,
        
        r.pay_as_you_grow_option AS pay_as_you_grow_option,
        
        -- ================================================================
        -- EXPOSURE SIZE BANDS
        -- ================================================================
        CASE
            WHEN r.current_contractual_balance < 500000 THEN '1. Up to £500k'
            WHEN r.current_contractual_balance >= 500000 AND r.current_contractual_balance < 1000000 THEN '2. £500k to <£1m'
            WHEN r.current_contractual_balance >= 1000000 AND r.current_contractual_balance < 1750000 THEN '3. £1m to <£1.75m'
            WHEN r.current_contractual_balance >= 1750000 AND r.current_contractual_balance < 2500000 THEN '4. £1.75m to <£2.5m'
            WHEN r.current_contractual_balance >= 2500000 AND r.current_contractual_balance < 3500000 THEN '5. £2.5m to <£3.5m'
            ELSE '6. >£3.5m'
        END AS exposure_size_band,
        
        CASE
            WHEN r.current_contractual_balance <= 150000 THEN '1. ≤150,000'
            WHEN r.current_contractual_balance > 150000 AND r.current_contractual_balance <= 250000 THEN '2. >150,000, ≤250,000'
            WHEN r.current_contractual_balance > 250000 AND r.current_contractual_balance <= 350000 THEN '3. >250,000, ≤350,000'
            WHEN r.current_contractual_balance > 350000 AND r.current_contractual_balance <= 500000 THEN '4. >350,000, ≤500,000'
            WHEN r.current_contractual_balance > 500000 AND r.current_contractual_balance <= 1000000 THEN '5. >500,000, ≤1,000,000'
            ELSE '6. >1,000,000'
        END AS exposure_size_band_fs,
        
        -- ================================================================
        -- ARREARS & BALANCE
        -- ================================================================
        r.arrears_balance AS arrears_balance,
        
        r.original_balance AS original_balance,
        
        r.total_vat_deferred AS total_vat_deferred,
        
        r.balloon_payment AS balloon_payment,
        
        r.contractual_repayment_amount_outside_any_capital_repayment_holiday AS contractual_repayment_amount_outside_any_capital_repayment_holiday,
        
        -- ================================================================
        -- ADDITIONAL PROPERTIES
        -- ================================================================
        r.brand AS brand,
        
        r.high_emission_vehicle_low_emission_vehicle AS vehicle_emission,
        
        r.age_of_asset_at_time_of_finance AS "age_of_asset_(at_time_of_finance)",
        
        r.hmo_or_mufb AS hmo_or_mufb,
        
        r.epc_rating AS epc_rating,
        
        r.property_backed_yn AS "property_backed_y/n",
        
        -- ================================================================
        -- SECURITY INFORMATION
        -- ================================================================
        CASE 
            WHEN r.security_type = 'Garage Vehicle Showrooms' THEN 'Garage / Vehicle showrooms'
            WHEN r.security_type = 'Convenience Retail Store' THEN 'Retail Units (Lock Up)'
            WHEN r.security_type = 'Semi Commercial Investment Property - 20% to 50% residential floorspace' THEN 'Semi Commercial Property – less than 50%'
            WHEN r.security_type = 'Semi Commercial Investment Property - 51% to 80% residential floorspace' THEN 'Semi Commercial Property – 50% to 99%'
            ELSE r.security_type
        END AS security_type,
        
        r.sub_security_type AS sub_security_type,
        
        r.tangible_collateral_count AS tangible_collateral_count,
        
        r.guarantor_count AS guarantor_count,
        
        r.valuation_amount AS original_valuation,
        
        r.original_valuation_date AS original_valuation_date,
        
        CASE WHEN r.account_id = 'ZH3966' THEN 1500000 ELSE r.security_value END AS security_value_pre_index,
        
        r.current_valuation_date AS latest_valuation_date,
        
        -- ================================================================
        -- DAYS PAST DUE & FORBEARANCE
        -- ================================================================
        r.days_past_due_dpd AS days_past_due,
        
        r.number_of_missed_payments_inferred_dpd AS number_of_missed_payments_inferred_dpd,
        
        r.forbearance_flag AS forbearance_flag,
        
        r.insolvency_flag AS insolvency_flag,
        
        r.arrears_stage AS arrears_stage,
        
        -- ================================================================
        -- RISK GRADES
        -- ================================================================
        CASE WHEN r.current_rg IS NULL THEN 10 ELSE r.current_rg END AS current_rg,
        
        CASE 
            WHEN r.origination_rg IS NULL THEN 10 
            ELSE r.origination_rg
        END AS origination_rg,
        
        CASE 
            WHEN r.origination_after_1m_rg IS NULL THEN 10 
            ELSE r.origination_after_1m_rg
        END AS origination_after_1m_rg,
        
        CASE 
            WHEN r.sicr_current_rg IS NULL THEN 10 
            ELSE r.sicr_current_rg
        END AS sicr_current_rg,
        
        r.origination_rg_v1 AS origination_rg_v1,
        
        r.current_rg_v1 AS current_rg_v1,
        
        -- ================================================================
        -- FLAGS & STATUS
        -- ================================================================
        'FALSE' AS watchlist_flag,
        
        'FALSE' AS watchlist,
        
        r.restructure_flag AS restructure_flag,
        r.legal_status AS legal_status,
        r.migration_source AS migration_source,
        r.migration_phase AS migration_phase,
        
        -- ================================================================
        -- NEW LOAN FLAG (DuckDB date comparison)
        -- ================================================================
        CASE 
            WHEN strftime(r.start_date, '%b-%Y') = strftime(CURRENT_DATE, '%b-%Y') THEN 'Y'
            ELSE 'N'
        END AS new_loan_flag,
        
        -- ================================================================
        -- ARREARS BAND
        -- ================================================================
        CASE 
            WHEN r.days_past_due_dpd = 0 THEN '1. Up to date'
            WHEN r.days_past_due_dpd = 1 THEN '2. 1DPD - 29DPD'
            WHEN r.days_past_due_dpd > 1 AND r.days_past_due_dpd < 90 THEN '3. 30DPD - 89DPD'
            WHEN r.days_past_due_dpd > 90 THEN '4. 90+ DPD' 
        END AS arrears_band,
        
        CASE WHEN r.current_rg = 6 THEN 'Y' ELSE 'N' END AS "rg6+_(y/n)",
        
        -- ================================================================
        -- RISK GRADE CATEGORIES
        -- ================================================================
        CASE 
            WHEN r.current_rg < 3 THEN '1. Very Low Risk'
            WHEN r.current_rg >= 3 AND r.current_rg < 5 THEN '2. Low Risk'
            WHEN r.current_rg >= 5 AND r.current_rg < 8 THEN '3. Medium Risk'
            WHEN r.current_rg >= 8 AND r.current_rg < 10 THEN '4. High Risk'
            WHEN r.current_rg >= 10 THEN '5. Default'
        END AS current_rg_category,
        
        CASE 
            WHEN r.current_rg_v1 < 5 THEN '1. Low'
            WHEN r.current_rg_v1 >= 5 AND r.current_rg_v1 < 8 THEN '2. Medium'
            WHEN r.current_rg_v1 >= 8 THEN '3. High'
        END AS current_rg_category_fs,
        
        r.current_rg * r.current_contractual_balance AS "sum_product_(current_credit_grade)",
        
        r.connection_id AS connection_id,
        
        r.ifrs9_product_type AS ifrs9_product_type,
        
        r.cre_flag AS cre_flag,
        
        -- ================================================================
        -- SOLE TRADER FLAG
        -- ================================================================
        CASE 
            WHEN r.legal_status IN ('Individual', 'Joint', 'Partnership', 'Sole Trader') THEN 1
            ELSE 0
        END AS sole_trader_pma_flag,
        
        -- ================================================================
        -- POCI FLAG (LSK-123)
        -- ================================================================
        CASE 
            WHEN r.account_id IN (
                'CA002509', 'CA002530', 'CA002484', 'CA002505', 'CA002481', 'CA002495',
                'CA002448', 'CA002429', 'CA002344', 'CA002439', 'CA002368', 'CA001779',
                'CA002348', 'CA002404', 'CA002386', 'CA002335', 'CA002381', 'CA002374',
                'CA002143', 'CA002208', 'CA002260', 'CA002250', 'CA002111', 'CA001789'
            ) THEN 'Y'
            ELSE 'N'
        END AS poci_flag,
        
        -- ================================================================
        -- CREDIT SCORES (from latest_scores CTE)
        -- ================================================================
        ls.original_credit_score AS commercial_delphi_score,
        ls.original_credit_score AS commercial_delphi_score_orig,
        NULL AS delphi_cashflow_score,
        NULL AS delphi_cashflow_score_orig,
        NULL AS fc_delphi_band,
        NULL AS fc_delphi_band_orig
        
    FROM 'parquet_files/rmc_tuscan.parquet' r
    LEFT JOIN latest_scores ls 
        ON r.account_id = ls.loan_id AND ls.rn = 1
    
    -- Use the maximum reporting_date available in the data
    WHERE r.reporting_date = (SELECT MAX(reporting_date) FROM 'parquet_files/rmc_tuscan.parquet')
      AND r.account_id != 'CA001880'
)

-- ============================================================================
-- FINAL SELECT
-- ============================================================================

SELECT * FROM main_data
ORDER BY account_id ASC, reporting_date DESC;
