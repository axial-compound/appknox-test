# RMC Tuscan Reports Generator

Automated pipeline for generating RMC (Risk Management Committee) reports for Tuscan bridging finance portfolio.

---

## 📦 For New Users - Getting Started

### 1️⃣ Install Dependencies

**Option A: Automated Setup (Recommended)**

On macOS/Linux:
```bash
./setup.sh
```

On Windows:
```batch
setup.bat
```

**Option B: Manual Setup**
```bash
pip install -r requirements.txt
```

See [INSTALL.md](INSTALL.md) for detailed installation instructions and troubleshooting.

### 2️⃣ Run the Pipeline

**Quick Test (using included sample data):**

On macOS/Linux:
```bash
./run_example.sh
```

On Windows:
```batch
run_example.bat
```

**Or run manually:**
```bash
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

**Note:** The pipeline automatically detects and converts these additional files if present:
- `input_files/tuscan/risk_info.xlsx` - Risk information (optional)
- `input_files/tuscan/sic_code.xlsx` - SIC codes (optional)

### 3️⃣ Check Results

Reports are automatically saved in `output_files/mm-yyyy/` folder based on the current month.

**Example:** Running in October 2025 creates:
```
output_files/10-2025/
├── rmc_tuscan_report.xlsx      (104 columns)
├── rmc_masterfile_report.xlsx  (124 columns) ⭐ Main Report
└── rmc_ifrs9_report.xlsx       (48 columns)
```

---

## 🚀 Quick Start

**Generate all reports with one command:**

```bash
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

**That's it!** In less than 1 second, you'll have:
- ✅ 3 Excel reports ready for review
- ✅ 3 Parquet datasets for ad-hoc queries
- ✅ All data validated and transformed

## What It Does

The pipeline automates 5 steps:

1. **CSV → Parquet Conversion** - Converts input files to efficient columnar format
2. **RMC Tuscan Report** - Generates intermediate analytical dataset (104 columns)
3. **Parquet Creation** - Creates queryable dataset for downstream reports
4. **RMC Masterfile Report** - Produces comprehensive report (124 columns) ⭐
5. **RMC IFRS9 Report** - Creates IFRS9 compliance report (48 columns)

## Output Files

### Excel Reports (for users)
- `output_files/mm-yyyy/rmc_tuscan_report.xlsx` - 104 columns, intermediate dataset
- `output_files/mm-yyyy/rmc_masterfile_report.xlsx` - 124 columns, **main report** ⭐
- `output_files/mm-yyyy/rmc_ifrs9_report.xlsx` - 48 columns, IFRS9 compliance

**Note:** Reports are automatically organized by current month/year (mm-yyyy format) when the script runs.

### Parquet Files (for queries)
- `parquet_files/loan_tape.parquet` - Loan-level data
- `parquet_files/security_tape.parquet` - Security/collateral data
- `parquet_files/risk_info.parquet` - Risk information (auto-generated if Excel file present)
- `parquet_files/sic_code.parquet` - SIC codes (auto-generated if Excel file present)
- `parquet_files/rmc_tuscan.parquet` - Analytical dataset

## Requirements

### Software
- Python 3.7+
- Required packages (install with `pip install -r requirements.txt`):
  - pandas
  - pyarrow
  - openpyxl
  - duckdb

### Input Files
- **loan_tape.csv** - Loan-level details (~119 columns) **[Required]**
- **security_tape.csv** - Security/collateral information (~44 columns) **[Required]**
- **risk_info.xlsx** - Risk information (~16 columns) **[Optional - Auto-detected]**
- **sic_code.xlsx** - SIC code mappings (~12 columns) **[Optional - Auto-detected]**

## Installation

```bash
# Clone or download the project
cd parquet-retrieval

# Install dependencies
pip install -r requirements.txt

# Run the pipeline
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv
```

## Usage

### Basic Usage

```bash
python generate_rmc_reports.py <loan_tape.csv> <security_tape.csv>
```

### Examples

```bash
# Standard usage
python generate_rmc_reports.py input_files/tuscan/loan_tape.csv input_files/tuscan/security_tape.csv

# From different location
python generate_rmc_reports.py /path/to/loan_tape.csv /path/to/security_tape.csv

# View help
python generate_rmc_reports.py --help
```

## Expected Output

```
================================================================================
RMC TUSCAN REPORT PIPELINE
================================================================================

STEP 1/5: Convert input CSV files to Parquet
✓ Converted Loan Tape CSV (194 rows, 119 columns)
✓ Converted Security Tape CSV (484 rows, 44 columns)

STEP 2/5: Generate RMC Tuscan Report (Intermediate)
✓ Query executed successfully (108 rows, 104 columns)
✓ Excel file created (62.72 KB)

STEP 3/5: Convert RMC Tuscan Report to Parquet
✓ Parquet file created (108 rows, 104 columns)

STEP 4/5: Generate RMC Masterfile Report
✓ Query executed successfully (108 rows, 124 columns)
✓ Excel file created (74.82 KB)

STEP 5/5: Generate RMC IFRS9 Report
✓ Query executed successfully (108 rows, 48 columns)
✓ Excel file created (27.45 KB)

PIPELINE COMPLETED SUCCESSFULLY!
Duration: 0.97 seconds
✓ All reports generated successfully!
```

## Report Descriptions

### 1. RMC Masterfile Report ⭐ (Main Report)
**File:** `output_files/mm-yyyy/rmc_masterfile_report.xlsx`  
**Columns:** 124  
**Purpose:** Comprehensive regulatory and management report

**Key Sections:**
- Borrower information and demographics
- Loan details, dates, and terms
- Interest rates and LTV calculations
- Risk grades and credit scores
- Exposure size bands and classifications
- Security and collateral information
- Portfolio categorizations

### 2. RMC Tuscan Report (Intermediate)
**File:** `output_files/mm-yyyy/rmc_tuscan_report.xlsx`  
**Columns:** 104  
**Purpose:** Intermediate analytical dataset

**Use Cases:**
- Foundation for other reports
- Ad-hoc analysis via SQL
- Data validation

### 3. RMC IFRS9 Report
**File:** `output_files/mm-yyyy/rmc_ifrs9_report.xlsx`  
**Columns:** 48  
**Purpose:** IFRS9 accounting compliance

**Key Fields:**
- Contractual balances with first charge
- Interest rate schedules
- Risk grade alignments
- Deduction period calculations
- Credit scoring (Delphi)

## Ad-Hoc Queries

Run custom SQL queries against the Parquet files:

```bash
# Query the masterfile data
python query_parquet.py -f parquet_files/rmc_tuscan.parquet "SELECT * FROM 'parquet_files/rmc_tuscan.parquet' WHERE days_past_due_dpd > 0"

# Export custom query results
python export_query_results.py tuscan_queries/custom_query.sql output.xlsx
```

## Performance

| Dataset Size | Execution Time |
|--------------|----------------|
| Small (50 loans) | 0.5 seconds |
| Medium (200 loans) | 1.0 seconds |
| Large (1,000 loans) | 3-5 seconds |

## Project Structure

```
parquet-retrieval/
├── generate_rmc_reports.py        ← Main pipeline script
├── query_parquet.py               ← Ad-hoc query tool
├── export_query_results.py        ← Export tool
├── requirements.txt               ← Python dependencies
│
├── tuscan_queries/                ← SQL queries
│   ├── rmc_tuscan.sql
│   ├── rmc_tuscan_masterfile.sql
│   └── rmc_tuscan_IRFS9.sql
│
├── input_files/tuscan/            ← Input CSV files
│   ├── loan_tape.csv
│   └── security_tape.csv
│
├── parquet_files/                 ← Generated Parquet files
│   ├── loan_tape.parquet
│   ├── security_tape.parquet
│   └── rmc_tuscan.parquet
│
└── output_files/                  ← Generated Excel reports (by date)
    └── mm-yyyy/                   ← Date-specific folders (e.g., 09-2025)
        ├── rmc_tuscan_report.xlsx
        ├── rmc_masterfile_report.xlsx
        └── rmc_ifrs9_report.xlsx
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| File not found | Verify file paths are correct |
| SQL error | Check parquet files exist in `parquet_files/` |
| Binding error (sic_code) | Ensure sic_code.xlsx is present, delete old parquet files, re-run pipeline |
| 0 rows returned | Date filter in SQL may not match your data |
| Permission denied | Ensure write access to `output_files/` |

**Run diagnostics to check your environment:**
```bash
python diagnose_environment.py
```

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for detailed solutions.

## Documentation

- 📖 [PIPELINE_USER_GUIDE.md](PIPELINE_USER_GUIDE.md) - Complete user guide and detailed documentation
- 📋 [QUICK_REFERENCE.md](QUICK_REFERENCE.md) - Quick reference and command examples

## Features

- ✅ **Automated** - Single command execution
- ✅ **Fast** - Sub-second processing
- ✅ **Reliable** - Comprehensive error handling
- ✅ **Efficient** - Uses columnar Parquet format
- ✅ **Flexible** - SQL-based transformations
- ✅ **Complete** - 3 reports covering all requirements

## Technical Details

- **SQL Engine:** DuckDB (in-memory, optimized for analytics)
- **File Format:** Parquet (columnar, compressed)
- **Output Format:** Excel (.xlsx) with auto-formatted columns
- **Language:** Python 3.7+

## Support

For issues or questions:
1. Check [PIPELINE_USER_GUIDE.md](PIPELINE_USER_GUIDE.md) for detailed documentation
2. Review error messages in pipeline output
3. Verify input file formats match requirements

## License

Internal use only.

---

**Quick Tip:** Run `python generate_rmc_reports.py` with your CSV files to get started immediately! 🚀
